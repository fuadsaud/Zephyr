package zephyr.ui;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.UIManager;

import net.miginfocom.layout.CC;
import net.miginfocom.swing.MigLayout;
import zephyr.Strings;

/**
 * A dialog containig information aabout Zephyr Text Editor.
 * 
 * @author Fuad Saud
 * 
 */
public class AboutDialog extends JDialog {

	/**
	 * Serial version ID.
	 */
	private static final long serialVersionUID = -5597623599632133128L;

	private final JDialog license;

	/**
	 * Creates a dialog with information about the software.
	 * 
	 * @param owner
	 *            the Frame from which the dialog is displayed
	 */
	public AboutDialog(JFrame owner) {
		super(owner, "About Zephyr", true);

		setLayout(new MigLayout("wrap 1", "[center][right][left][c]",
				"[top][center][b]"));

		license = new JDialog(this, Strings.FULL_NAME + " " + Strings.VERSION
				+ " License", true);
		license.setLocationRelativeTo(owner);

		initLabels();
		initButton();
		initLicense();

		if (UIManager.getLookAndFeel().getClass().getName()
				.equals("com.sun.java.swing.plaf.windows.WindowsLookAndFeel")) {
			setSize(310, 300);
		} else {
			setSize(345, 300);
		}
		setResizable(false);
		setLocationRelativeTo(owner);
	}

	private void browserCall() {
		if (System.getProperty("os.name").startsWith("Windows")) {
			try {
				Runtime.getRuntime().exec(
						System.getenv("programfiles")
								+ "/Internet Explorer/iexplore.exe"
								+ Strings.HOME_PAGE);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Initializes the button.
	 */
	private void initButton() {
		JButton license = new JButton("License");
		license.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				AboutDialog.this.license.setVisible(true);

			}
		});
		add(license, new CC().gapTop("10").alignX("center"));
	}

	/**
	 * Initializes the labels on the dialog.
	 */
	private void initLabels() {
		add(new JLabel(new ImageIcon(Toolkit.getDefaultToolkit().getImage(
				Strings.ICON128PNG))), "align center");

		JLabel zephyr = new JLabel(Strings.FULL_NAME);
		zephyr.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
		add(zephyr, "align center");

		JLabel version = new JLabel(Strings.VERSION);
		version.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
		add(version, "align center");

		add(new JLabel(Strings.COPYLEFT), "align center");

		JLabel url = new JLabel(Strings.HOME_PAGE);
		url.setForeground(Color.BLUE);
		url.setCursor(new Cursor(Cursor.HAND_CURSOR));
		url.addMouseListener(new MouseListener() {

			@Override
			public void mouseClicked(MouseEvent e) {
				browserCall();
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub

			}
		});
		add(url, "align center");
	}

	/**
	 * Initializes the text area.
	 */
	private void initLicense() {
		JTextArea text = new JTextArea(Strings.DESCRIPTION);
		text.setWrapStyleWord(true);
		text.setFont(new Font("Courier New", Font.PLAIN, 14));
		text.setEditable(false);
		JScrollPane scroll = new JScrollPane();
		scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroll.getViewport().setBorder(null);
		scroll.getViewport().add(text);
		license.add(scroll);
		license.setResizable(true);
		license.setSize(720, 400);

	}
}
