package zephyr.ui;

import javax.swing.JDialog;

/**
 * @author Fuad Saud
 * 
 */
public class SettingsDialog extends JDialog {

	/**
	 * Serial version ID
	 */
	private static final long serialVersionUID = 3252739958878696995L;

}
