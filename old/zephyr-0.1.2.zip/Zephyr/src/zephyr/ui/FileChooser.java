package zephyr.ui;

import java.awt.Component;
import java.awt.HeadlessException;
import java.io.File;
import java.io.FileNotFoundException;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 * This class extends {@link JFileChooser} and the only function it adds to it
 * is checking file names to add right extension based on the file filters.
 * 
 * @author Fuad Saud
 * 
 */
public class FileChooser extends JFileChooser {

	/**
	 * Serial version ID.
	 */
	private static final long serialVersionUID = -1245645604994562256L;

	/**
	 * Calls the {@link JFileChooser} and adds all
	 * {@link FileNameExtensionFilter} used on Zephyr.
	 */
	public FileChooser() {
		super();

		// Adds file name extension filters
		addChoosableFileFilter(new FileNameExtensionFilter("C/C++ source files", "c", "cpp", "h"));
		addChoosableFileFilter(new FileNameExtensionFilter("CSS files", "css"));
		addChoosableFileFilter(new FileNameExtensionFilter("HTML files", "html", "htm", "xhtml"));
		addChoosableFileFilter(new FileNameExtensionFilter("Java files", "java"));
		addChoosableFileFilter(new FileNameExtensionFilter("JSON files", "json"));
		addChoosableFileFilter(new FileNameExtensionFilter("PHP files", "php"));
		addChoosableFileFilter(new FileNameExtensionFilter("Perl files", "pl"));
		addChoosableFileFilter(new FileNameExtensionFilter("Properties files", "properties",
				"plist"));
		addChoosableFileFilter(new FileNameExtensionFilter("Python files", "py"));
		addChoosableFileFilter(new FileNameExtensionFilter("Ruby files", "rb"));
		addChoosableFileFilter(new FileNameExtensionFilter("SQL files", "sql"));
		addChoosableFileFilter(new FileNameExtensionFilter("Text files", "txt"));
		addChoosableFileFilter(new FileNameExtensionFilter("XML files", "xml"));
		addChoosableFileFilter(new FileNameExtensionFilter("YAML files", "yml", "yaml"));
	}

	/**
	 * Calls {@link JFileChooser#showOpenDialog(Component)} and checks if the
	 * selected file exits.
	 * 
	 * @param parent
	 *            the parent component of the dialog, can be null; see
	 *            {@code showDialog} for details
	 * @return the return state of the file chooser on popdown:
	 *         JFileChooser.CANCEL_OPTION <br/>
	 *         JFileChooser.APPROVE_OPTION <br/>
	 *         JFileChooser.ERROR_OPTION if an error occurs or the dialog is
	 *         dismissed
	 * @throws HeadlessException
	 *             if GraphicsEnvironment.isHeadless() returns true.
	 * 
	 * @throws FileNotFoundException
	 *             if selected file does not exists anymore (it might have been
	 *             deleted during openDialog was opened).
	 * @see JFileChooser#showOpenDialog(Component)
	 */
	public int open(Component parent) throws HeadlessException, FileNotFoundException {
		int ret = super.showOpenDialog(parent);
		if (ret == APPROVE_OPTION) {
			if (!getSelectedFile().exists()) {
				throw new FileNotFoundException();
			}
		}
		return ret;
	}

	/**
	 * Calls JFileChooser#showSaveDialog(java.awt.Component) and checks if the
	 * typed file name contains the respective selected file name filter
	 * extensions. Case not, it adds default extension to the file name.
	 * 
	 * @see JFileChooser#showSaveDialog(java.awt.Component)
	 */
	public int save(Component parent) throws HeadlessException {
		int result = showSaveDialog(parent);
		if (result == APPROVE_OPTION) {
			if (!getFileFilter().equals(getAcceptAllFileFilter())) {
				FileNameExtensionFilter filter = (FileNameExtensionFilter) getFileFilter();
				File selectedFile = getSelectedFile();
				String fileName = selectedFile.getName();

				boolean fileNameHasExtension = false;

				// Tests if there is a '.' on the fileName and if it's not the
				// last char
				if (fileName.contains(".") && fileName.charAt(fileName.length() - 1) != ('.')) {
					for (String extension : filter.getExtensions()) {
						// Gets a substring of file name that starts with the
						// last '.' on the string
						String end = fileName.substring(fileName.lastIndexOf('.') + 1);
						if (end.equalsIgnoreCase(extension)) {
							fileNameHasExtension = true;
						}
					}
				}

				if (!fileNameHasExtension) {
					selectedFile = new File(selectedFile.getPath() + "."
							+ filter.getExtensions()[0]);
					setSelectedFile(selectedFile);
				}
			}
		}

		return result;
	}

}
