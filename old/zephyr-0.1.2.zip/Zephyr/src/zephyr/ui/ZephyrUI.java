package zephyr.ui;

import java.awt.Component;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import zephyr.Strings;
import zephyr.file.TextFileStreamer;

/**
 * @author Fuad Saud
 * 
 */
public class ZephyrUI extends JFrame {

	/**
	 * Serial version ID.
	 */
	private static final long serialVersionUID = 3220666579206122227L;

	private final DocumentTabbedPane tabs = new DocumentTabbedPane();

	/**
	 * A {@link JFileChooser} to manage the open and save actions.
	 */
	private final FileChooser fileChooser = new FileChooser();

	/**
	 * A simple file manager to handle streams and low level file treatment.
	 */
	private final TextFileStreamer fileManager = new TextFileStreamer();

	/**
	 * Creates a consistent state editor.
	 */
	public ZephyrUI() {
		setTitle("Untitled", null);

		initComponents();
	}

	public ZephyrUI(String[] args) {
		this();
		for (int i = 0; i < args.length; i++) {
			if (args[i] != null) {
				openOnBackground(args[i]);
			}
		}
	}

	/**
	 * Pop up an {@link AboutDialog}.
	 */
	private void about() {
		new AboutDialog(this).setVisible(true);
		// JOptionPane.showMessageDialog(this,
		// "Zephyr Text Editor   0.1.1 Alpha\nCopyleft " + (char) 169
		// + " 2011 - Fuad Saud - Couple of rights reserveds :)",
		// "About Zephyr", JOptionPane.PLAIN_MESSAGE);
	}

	/**
	 * Close the selected document, prompting the user in case of the file is
	 * not saved.
	 */
	private boolean close() {
		Document doc = tabs.getSelectedComponent();
		if (!doc.isSaved()) {
			int opcao = JOptionPane.showConfirmDialog(this,
					"Do you want to save changes on " + doc.getDocName() + "?",
					"Close", JOptionPane.YES_NO_CANCEL_OPTION,
					JOptionPane.QUESTION_MESSAGE);
			if (opcao == JOptionPane.YES_OPTION) {
				save();
			} else if (opcao == JOptionPane.CANCEL_OPTION) {
				return false;
			}
		}

		if (tabs.getComponents().length == 1) {
			newDocument();
			tabs.remove(0);
		} else {
			tabs.remove(tabs.getSelectedIndex());
		}
		return true;
	}

	/**
	 * Exits application, calling the {@linkplain ZephyrUI#close()} method to
	 * all opened documents.
	 */
	private void exit() {
		boolean allClosed = true;
		for (int i = tabs.getComponentCount() - 1; i >= 0; i--) {
			tabs.setSelectedIndex(i);
			if (!close()) {
				allClosed = false;
			}
		}
		if (allClosed) {
			System.exit(0);
		}
	}

	/**
	 * Initializes all the components in the frame.
	 */
	private void initComponents() {
		initMenuBar();
		initTabs();

		addWindowListener(new WindowListener() {

			@Override
			public void windowActivated(WindowEvent arg0) {

			}

			@Override
			public void windowClosed(WindowEvent arg0) {

			}

			@Override
			public void windowClosing(WindowEvent arg0) {
				exit();
			}

			@Override
			public void windowDeactivated(WindowEvent arg0) {

			}

			@Override
			public void windowDeiconified(WindowEvent arg0) {

			}

			@Override
			public void windowIconified(WindowEvent arg0) {

			}

			@Override
			public void windowOpened(WindowEvent arg0) {

			}
		});
		setIconImage(Toolkit.getDefaultToolkit()
				.getImage("./res/zephyr128.png"));
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		setSize(480, 600);
		setLocation(250, 150);

		newDocument();
	}

	/**
	 * Initializes the {@code menuBar}.
	 */
	private void initMenuBar() {
		JMenuBar menuBar = new JMenuBar();

		JMenu file = new JMenu("File");

		JMenuItem newFile = new JMenuItem("New");
		newFile.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				newDocument();
			}
		});
		file.add(newFile);

		JMenuItem open = new JMenuItem("Open...");
		open.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				open();
			}
		});
		file.add(open);

		file.addSeparator();

		JMenuItem close = new JMenuItem("Close");
		close.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				close();
			}
		});
		file.add(close);

		file.addSeparator();

		JMenuItem save = new JMenuItem("Save");
		save.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				save();
			}
		});
		file.add(save);

		JMenuItem saveAs = new JMenuItem("Save As...");
		saveAs.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				saveAs();
			}
		});
		file.add(saveAs);

		file.addSeparator();

		JMenuItem exit = new JMenuItem("Exit");
		exit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				exit();
			}
		});
		file.add(exit);

		menuBar.add(file);

		JMenu view = new JMenu("View");
		menuBar.add(view);

		JMenu help = new JMenu("Help");

		JMenuItem about = new JMenuItem("About Zephyr...");
		about.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				about();
			}
		});
		help.add(about);

		menuBar.add(help);

		setJMenuBar(menuBar);
	}

	/**
	 * Initializes the {@code tabs}.
	 */
	private void initTabs() {
		tabs.addChangeListener(new ChangeListener() {

			@Override
			public void stateChanged(ChangeEvent e) {
				tabChanged();
			}
		});
		tabs.addMouseListener(new MouseListener() {

			@Override
			public void mouseClicked(MouseEvent e) {
				if (e.getButton() == MouseEvent.BUTTON2) {
					close();
				} else if (e.getButton() == MouseEvent.BUTTON1
						&& e.getClickCount() == 2) {
					newDocument();
				}
			}

			@Override
			public void mouseEntered(MouseEvent e) {

			}

			@Override
			public void mouseExited(MouseEvent e) {

			}

			@Override
			public void mousePressed(MouseEvent e) {

			}

			@Override
			public void mouseReleased(MouseEvent e) {

			}
		});
		getContentPane().add(tabs);
	}

	/**
	 * TODO
	 * 
	 * @param path
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private int isOpen(String path) {
		Component[] components = tabs.getComponents();

		for (int i = 0; i < components.length; i++) {
			String path1 = ((GenericScrollPane<Document>) components[i])
					.getComponent().getPath();
			if (path.equals(path1)) {
				return i;
			}
		}
		return -1;
	}

	/**
	 * Creates a new tab with a blank {@link Document}.
	 */
	private void newDocument() {
		tabs.addTab();
		tabs.setSelectedIndex(tabs.getComponentCount() - 1);
	}

	/**
	 * Shows the {@code fileChooser} and creates a new tab and a document with
	 * the content of the chosen file. The content is copied to the memory (the
	 * stream don't remain opened and other applications can use the file).
	 */
	private void open() {
		File file = null;
		try {
			if (fileChooser.open(this) == JFileChooser.APPROVE_OPTION) {
				file = null;
				file = fileChooser.getSelectedFile();

				// Check if the document is already open
				int index;
				if ((index = isOpen(file.getPath())) != -1) {
					tabs.setSelectedIndex(index);
					return;
				}

				String text = fileManager.open(file)[2];
				tabs.addTab(file.getName(), file.getPath(), text);
				if (tabs.getSelectedComponent().isNewDocument()) {
					tabs.remove(tabs.getSelectedIndex());
				}
				tabs.setSelectedIndex(tabs.getComponentCount() - 1);
				setTitle(file.getName(), file.getPath());
			}
		} catch (FileNotFoundException e) {
			JOptionPane.showMessageDialog(this, "Can't find " + file.getPath(),
					"Error", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		} catch (IOException e) {
			JOptionPane.showMessageDialog(this,
					"Not able to open " + file.getPath(), "Error",
					JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}

	/**
	 * Open a file and add the content to a new {@link Document}. The main
	 * difference between {@link #open()} and this is that this method receive,
	 * by passing an argument, the path of the file to be opened, instead of
	 * showing the {@code fileChooser}. This method doesn't show any kind of
	 * dialog, even in case of an error.
	 * 
	 * @param path
	 *            The path of the file to be opened.
	 */
	private void openOnBackground(String path) {
		// Check if the document is already open
		int index;
		if ((index = isOpen(path)) != -1) {
			tabs.setSelectedIndex(index);
			return;
		}

		try {
			String[] file = fileManager.open(path);
			tabs.addTab(file[0], path, file[2]);
			if (tabs.getSelectedComponent().isNewDocument()) {
				tabs.remove(tabs.getSelectedIndex());
			}
			tabs.setSelectedIndex(tabs.getComponentCount() - 1);
			setTitle(file[0], path);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Saves the current document. If file is not {@code savedOnDisk}, prompts
	 * the {@code fileChooser} to select the destination file. If it's already
	 * on disk, it only overwrites it.
	 */
	private void save() {
		Document doc = tabs.getSelectedComponent();
		if (!doc.isSavedOnDisk()) {
			saveAs();
		} else {
			try {
				new TextFileStreamer().save(doc.getText(), doc.getPath());
			} catch (IOException e) {
				JOptionPane.showMessageDialog(this, "Ocurred an error saving  "
						+ doc.getPath(), "Error", JOptionPane.ERROR_MESSAGE);
				e.printStackTrace();
			}
			doc.setSaved(true);
			doc.setSavedOnDisk(true);
			tabs.setTitleStar(false);
		}
	}

	/**
	 * Saves the current document. It prompts the {@code fileChooser} to select
	 * the destination file.
	 */
	private void saveAs() {
		Document doc = tabs.getSelectedComponent();
		if (fileChooser.save(this) == JFileChooser.APPROVE_OPTION) {
			File file = null;
			try {
				file = fileChooser.getSelectedFile();
				// Flushes the content
				fileManager.save(tabs.getSelectedComponent().getText(), file);
				doc.setDocName(file.getName());
				doc.setPath(file.getPath());
				doc.setSaved(true);
				doc.setSavedOnDisk(true);
				setTitle(doc.getDocName(), doc.getPath());
				tabs.setTitleStar(false);
			} catch (IOException e) {
				JOptionPane.showMessageDialog(
						this,
						"Ocurred an error saving  "
								+ (doc.getPath() != null ? doc.getPath() : doc
										.getDocName()), "Error",
						JOptionPane.ERROR_MESSAGE);
				e.printStackTrace();
			}
		}
	}

	/**
	 * Sets the {@link ZephyrUI} title, on the format "{@code docName} -
	 * {@code docPath} - Zephyr"
	 * 
	 * @param docName
	 *            the name of the current document.
	 * @param docPath
	 *            the path of the current document.
	 */
	private void setTitle(String docName, String docPath) {
		if (docPath == null) {
			setTitle(docName + " - " + Strings.NAME);
		} else {
			setTitle(docName + " - "
					+ docPath.substring(0, docPath.lastIndexOf('\\') + 1)
					+ " - " + Strings.NAME);
		}

		try {
			tabs.setTitleAt(tabs.getSelectedIndex(), docName);
		} catch (ArrayIndexOutOfBoundsException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Changes the name of {@link ZephyrUI} based on the current document.
	 */
	private void tabChanged() {
		Document doc = tabs.getSelectedComponent();
		setTitle(doc.getDocName(), doc.getPath());
	}
}
