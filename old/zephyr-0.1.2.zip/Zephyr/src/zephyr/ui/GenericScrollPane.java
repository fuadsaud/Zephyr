package zephyr.ui;

import java.awt.Component;

import javax.swing.JScrollPane;

/**
 * @author Fuad Saud
 * 
 * @param <T>
 *            the type to be added on the scroll pane.
 */
public class GenericScrollPane<T extends Component> extends JScrollPane {

	/**
	 * Serial version ID.
	 */
	private static final long serialVersionUID = -1435005419107329120L;

	private T component;

	public void addOnViewPort(T component) {
		super.getViewport().add(component);
		this.component = component;
	}

	public T getComponent() {
		return component;
	}

}
