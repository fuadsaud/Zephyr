package zephyr;

import javax.swing.UIManager;

import zephyr.ui.ZephyrUI;

/**
 * Bootstraps the Text Editor application.
 * 
 * @author Fuad Saud
 * 
 */
public class Zephyr {

	/**
	 * @param args
	 *            Command line arguments.
	 */
	public static void main(String[] args) {
		int laf = (int) (Math.random() * 3);

		try {
			if (laf == 0) {
				UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
				laf++;
			} else if (laf == 1) {
				UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
				laf++;
			} else {
				UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
				laf = 0;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		new ZephyrUI(args).setVisible(true);
	}
}
