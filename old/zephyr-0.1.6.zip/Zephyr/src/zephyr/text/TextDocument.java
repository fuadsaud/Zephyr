package zephyr.text;

import static zephyr.Zephyr.STRINGS;

import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;
import javax.swing.undo.UndoManager;

public class TextDocument extends PlainDocument {

	/**
	 * Serial version ID.
	 */
	private static final long serialVersionUID = -4676679149064761964L;

	/**
	 * The name of the document.
	 */
	private String name;

	/**
	 * The path of the document on the disk.
	 */
	private String path;

	/**
	 * Indicates whether document is saved.
	 */
	private boolean saved;

	/**
	 * Indicates if the document was already flushed to the disc, independent of
	 * the {@code saved} flag.
	 */
	private boolean savedOnDisk;

	/**
	 * Indicates <code>true</code> when this is a just created blank document.
	 */
	private boolean newDocument;

	/**
	 * Creates a blank document with {@code name} "Untitled" and a null
	 * {@code path}.
	 */
	public TextDocument() {
		this(STRINGS.getProperty("untitled"), null, null);
		setSavedOnDisk(false);
		this.newDocument = true;
		putProperty("new", true);
	}

	/**
	 * Creates a document with the specified name, path and content
	 * 
	 * @param name
	 *            the document name.
	 * @param path
	 *            the document path.
	 * @param content
	 *            the content to be set on text area.
	 */
	public TextDocument(String name, String path, String content) {
		try {
			insertString(0, content, null);
		} catch (BadLocationException e) {
			e.printStackTrace();
		}
		setName(name);
		setPath(path);

		setSaved(true);
		setSavedOnDisk(true);

		addUndoableEditListener(new UndoManager());
		addDocumentListener(new DocumentListener() {

			@Override
			public void changedUpdate(DocumentEvent e) {
				setSaved(false);
			}

			@Override
			public void insertUpdate(DocumentEvent e) {
				setSaved(false);
			}

			@Override
			public void removeUpdate(DocumentEvent e) {
				setSaved(false);
			}
		});

	}

	/**
	 * Returns the name of the document.
	 * 
	 * @return the name of the document.
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * Returns the path of the document.
	 * 
	 * @return the path of the document.
	 */
	public String getPath() {
		return path;
	}

	/**
	 * Returns <code>true</code> when this is a just created blank document.
	 * 
	 * @return the <code>newDocument</code> attribute.
	 */
	public boolean isNewDocument() {
		return newDocument;
	}

	/**
	 * Returns <code>true</code> if the document is saved; <code>false</code> if
	 * not.
	 * 
	 * @return the saved flag.
	 */
	public boolean isSaved() {
		return saved;
	}

	/**
	 * Returns <code>true</code> if the document is saved on the disk;
	 * <code>false</code> if not.
	 * 
	 * @return the savedOnDisk flag.
	 */
	public boolean isSavedOnDisk() {
		return savedOnDisk;
	}

	/**
	 * @param newDocument
	 *            the newDocument to set
	 */

	/**
	 * Sets the document name.
	 * 
	 * @param name
	 *            the new name.
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Sets the document path.
	 * 
	 * @param path
	 *            the path to set
	 */
	public void setPath(String path) {
		this.path = path;
	}

	/**
	 * Sets the {@code saved} attribute.
	 * 
	 * @param saved
	 *            the flag to set.
	 */
	public void setSaved(boolean saved) {
		this.newDocument = false;
		this.saved = saved;
	}

	/**
	 * Sets the {@code savedOnDisk} attribute.
	 * 
	 * @param savedOnDisk
	 *            the flag to set.
	 */
	public void setSavedOnDisk(boolean savedOnDisk) {
		this.savedOnDisk = savedOnDisk;
	}
}
