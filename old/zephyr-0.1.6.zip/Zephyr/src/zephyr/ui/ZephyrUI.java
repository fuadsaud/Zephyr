package zephyr.ui;

import static zephyr.Zephyr.PREFERENCES;
import static zephyr.Zephyr.STRINGS;

import java.awt.Component;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;
import javax.swing.undo.UndoManager;

import zephyr.Zephyr;
import zephyr.file.TextFileStreamer;
import zephyr.text.TextDocument;

/**
 * @author Fuad Saud
 * 
 */
public class ZephyrUI extends JFrame {

	/**
	 * Serial version ID.
	 */
	private static final long serialVersionUID = 3220666579206122227L;

	private final TextAreaTabbedPane tabs = new TextAreaTabbedPane();

	/**
	 * A {@link JFileChooser} to manage the open and save actions.
	 */
	private final FileChooser fileChooser = new FileChooser();

	/**
	 * A simple file manager to handle streams and low level file treatment.
	 */
	private final TextFileStreamer fileStreamer = new TextFileStreamer();

	/**
	 * Initializes ZephyrUI and loads documents from previous sessions.
	 */
	public ZephyrUI() {
		initComponents();
		updateTile();
	}

	/**
	 * Initializes ZephyrUI and try to open files based on the <code>args</code>
	 * , an array of paths. If <code>args.length == 0</code>, open documents
	 * from last session.
	 * 
	 * @param args
	 *            The paths of the files to be opened
	 */
	public ZephyrUI(String[] args) {
		this();
		if (args == null || args.length == 0) {
			loadPreviousSession();
		} else {
			// Open command line arguments
			for (int i = 0; i < args.length; i++) {
				if (args[i] != null) {
					open(args[i], true);
				}
			}
		}
	}

	/**
	 * Pop up an {@link AboutDialog}.
	 */
	private void about() {
		new AboutDialog(this).setVisible(true);
	}

	/**
	 * Close the selected document, prompting the user in case of the file is
	 * not saved.
	 * 
	 * @return <code>true</code> if the document was successfully closed
	 */
	private boolean close() {
		TextArea textArea = tabs.getSelectedComponent();
		if (!textArea.getTextDocument().isSaved()) {
			String path = textArea.getTextDocument().getPath() != null ? textArea
					.getTextDocument().getPath() : textArea.getTextDocument()
					.getName();
			int opcao = JOptionPane.showConfirmDialog(this,
					STRINGS.getProperty("save-changes") + " " + path + "?",
					STRINGS.getProperty("close"),
					JOptionPane.YES_NO_CANCEL_OPTION,
					JOptionPane.QUESTION_MESSAGE);
			if (opcao == JOptionPane.YES_OPTION) {
				save();
			} else if (opcao == JOptionPane.CANCEL_OPTION) {
				return false;
			}
		}

		if (tabs.getComponents().length == 1) {
			newDocument();
			tabs.remove(0);
		} else {
			tabs.remove(tabs.getSelectedIndex());
		}
		return true;
	}

	/**
	 * Closes all opened documents and saves the current session on the
	 * "session" file.
	 * 
	 * @return <code>true</code> if all documents were successfully closed
	 */
	private boolean closeAll() {
		boolean rememberCurrentSession = Boolean.parseBoolean(PREFERENCES
				.getProperty("remember-current-session"));
		StringBuilder paths = new StringBuilder();
		for (int i = tabs.getComponentCount() - 1; i >= 0; i--) {
			tabs.setSelectedIndex(i);
			if (tabs.getSelectedComponent().getTextDocument().getPath() != null) {
				paths.append(tabs.getSelectedComponent().getTextDocument()
						.getPath()
						+ ";");
			}
			if (!close()) {
				return false;
			}
		}
		if (rememberCurrentSession) {
			Zephyr.PREFERENCES.setProperty("session", paths.toString());
		} else {
			Zephyr.PREFERENCES.setProperty("session", "");
		}
		return true;
	}

	private boolean closeAllOthers() {
		int current = tabs.getSelectedIndex();
		for (int i = tabs.getComponentCount() - 1; i >= 0; i--) {
			tabs.setSelectedIndex(i);
			if (tabs.getSelectedIndex() != current) {
				if (!close()) {
					return false;
				}
			}
		}
		return true;
	}

	/**
	 * Closes all opened documents and calls {@linkplain Zephyr#shutdown()};
	 */
	private void exit() {
		if (closeAll()) {
			Zephyr.shutdown();
		}
	}

	/**
	 * Initializes all the components in the frame.
	 */
	private void initComponents() {
		initMenuBar();
		initTabs();

		addWindowListener(new WindowListener() {

			@Override
			public void windowActivated(WindowEvent arg0) {

			}

			@Override
			public void windowClosed(WindowEvent arg0) {

			}

			@Override
			public void windowClosing(WindowEvent arg0) {
				exit();

			}

			@Override
			public void windowDeactivated(WindowEvent arg0) {

			}

			@Override
			public void windowDeiconified(WindowEvent arg0) {

			}

			@Override
			public void windowIconified(WindowEvent arg0) {

			}

			@Override
			public void windowOpened(WindowEvent arg0) {

			}
		});
		setIconImage(Toolkit.getDefaultToolkit().getImage(
				this.getClass().getResource(Zephyr.IMAGES + "zephyr256.png")));
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		setSize(480, 600);
		setLocation(250, 150);
		newDocument();
	}

	/**
	 * Initializes the {@code menuBar}.
	 */
	private void initMenuBar() {
		JMenuBar menuBar = new JMenuBar();

		// File
		// -------------------------------------------------------------------------
		JMenu file = new JMenu(STRINGS.getProperty("file"));

		JMenuItem newDocument = new JMenuItem(STRINGS.getProperty("new"));
		newDocument.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				newDocument();
			}
		});
		newDocument.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N,
				KeyEvent.CTRL_DOWN_MASK));
		file.add(newDocument);

		JMenuItem open = new JMenuItem(STRINGS.getProperty("open") + "...");
		open.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				open();
			}
		});
		open.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O,
				KeyEvent.CTRL_DOWN_MASK));
		file.add(open);

		file.addSeparator();

		JMenuItem save = new JMenuItem(STRINGS.getProperty("save"));
		save.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				save();
			}
		});
		save.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,
				KeyEvent.CTRL_DOWN_MASK));
		file.add(save);

		JMenuItem saveAs = new JMenuItem(STRINGS.getProperty("save-as") + "...");
		saveAs.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				saveAs();
			}
		});
		saveAs.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,
				KeyEvent.CTRL_DOWN_MASK + KeyEvent.ALT_DOWN_MASK));
		file.add(saveAs);

		JMenuItem saveAll = new JMenuItem(STRINGS.getProperty("save-all"));
		saveAll.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				saveAll();
			}
		});
		saveAll.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,
				KeyEvent.CTRL_DOWN_MASK + KeyEvent.SHIFT_DOWN_MASK));
		file.add(saveAll);

		file.addSeparator();

		JMenuItem close = new JMenuItem(STRINGS.getProperty("close"));
		close.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				close();
			}
		});
		close.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_W,
				KeyEvent.CTRL_DOWN_MASK));
		file.add(close);

		JMenuItem closeAll = new JMenuItem(STRINGS.getProperty("close-all"));
		closeAll.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				closeAll();
			}
		});
		closeAll.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_W,
				KeyEvent.CTRL_DOWN_MASK + KeyEvent.ALT_DOWN_MASK));
		file.add(closeAll);

		JMenuItem closeAllOthers = new JMenuItem(
				STRINGS.getProperty("close-all-others"));
		closeAllOthers.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				closeAllOthers();
			}
		});
		closeAllOthers.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_W,
				KeyEvent.CTRL_DOWN_MASK + KeyEvent.SHIFT_DOWN_MASK));
		file.add(closeAllOthers);

		file.addSeparator();

		JMenuItem exit = new JMenuItem(STRINGS.getProperty("exit"));
		exit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				exit();
			}
		});
		exit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F4,
				KeyEvent.ALT_DOWN_MASK));
		file.add(exit);

		menuBar.add(file);

		// Edit
		// -------------------------------------------------------------------------

		JMenu edit = new JMenu(STRINGS.getProperty("edit"));

		JMenuItem undo = new JMenuItem(STRINGS.getProperty("undo"));
		undo.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					((UndoManager) tabs.getSelectedComponent()
							.getTextDocument().getUndoableEditListeners()[0])
							.undo();
				} catch (CannotUndoException ex) {
					ex.printStackTrace();
				}
			}
		});
		undo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Z,
				KeyEvent.CTRL_DOWN_MASK));
		edit.add(undo);

		JMenuItem redo = new JMenuItem(STRINGS.getProperty("redo"));
		redo.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					((UndoManager) tabs.getSelectedComponent()
							.getTextDocument().getUndoableEditListeners()[0])
							.redo();
				} catch (CannotRedoException ex) {
					ex.printStackTrace();
				}
			}
		});
		redo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Z,
				KeyEvent.CTRL_DOWN_MASK + KeyEvent.SHIFT_DOWN_MASK));
		edit.add(redo);

		JMenuItem preferences = new JMenuItem(
				STRINGS.getProperty("preferences") + "...");
		preferences.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				preferences();
			}
		});
		preferences.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_SPACE,
				KeyEvent.CTRL_DOWN_MASK));
		edit.add(preferences);

		menuBar.add(edit);

		// Edit
		// -------------------------------------------------------------------------

		JMenu view = new JMenu(STRINGS.getProperty("view"));

		menuBar.add(view);

		// Help
		// -------------------------------------------------------------------------

		JMenu help = new JMenu(STRINGS.getProperty("help"));

		JMenuItem about = new JMenuItem(STRINGS.getProperty("about-zephyr")
				+ "...");
		about.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				about();
			}
		});
		about.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0));
		help.add(about);

		menuBar.add(help);

		setJMenuBar(menuBar);
	}

	/**
	 * Initializes the {@code tabs}.
	 */
	private void initTabs() {
		tabs.addChangeListener(new ChangeListener() {

			@Override
			public void stateChanged(ChangeEvent e) {
				tabChanged();
			}
		});
		tabs.addMouseListener(new MouseListener() {

			@Override
			public void mouseClicked(MouseEvent e) {
				if (e.getButton() == MouseEvent.BUTTON2) {
					close();
				} else if (e.getButton() == MouseEvent.BUTTON1
						&& e.getClickCount() == 2) {
					newDocument();
				}
			}

			@Override
			public void mouseEntered(MouseEvent e) {

			}

			@Override
			public void mouseExited(MouseEvent e) {

			}

			@Override
			public void mousePressed(MouseEvent e) {

			}

			@Override
			public void mouseReleased(MouseEvent e) {

			}
		});
		getContentPane().add(tabs);
	}

	/**
	 * This methods checks if a document is already opened in the application,
	 * based on file's path.
	 * 
	 * @param path
	 *            The file path to be checked
	 * @return the index of the text area on the <code>tabs</code> or -1, case
	 *         not opened
	 */
	@SuppressWarnings("unchecked")
	private int isOpened(String path) {
		Component[] components = tabs.getComponents();

		for (int i = 0; i < components.length; i++) {
			String path1 = ((GenericScrollPane<TextArea>) components[i])
					.getComponent().getTextDocument().getPath();
			if (path.equals(path1)) {
				return i;
			}
		}
		return -1;
	}

	/**
	 * Open the documents from previous sessions, based on the "session" file.
	 */
	private void loadPreviousSession() {
		String session = Zephyr.PREFERENCES.getProperty("session");
		if (session != null) {
			String[] paths = session.split(";");
			for (int i = paths.length - 1; i >= 0; i--) {
				if (!paths[i].isEmpty()) {
					open(paths[i], false);
				}
			}
		}
	}

	/**
	 * Creates a new tab with a blank {@link TextArea}.
	 */
	private void newDocument() {
		tabs.addTab();
		tabs.setSelectedIndex(tabs.getComponentCount() - 1);
	}

	/**
	 * Shows the {@code fileChooser} and creates a new tab and a document with
	 * the content of the chosen file. The content is copied to the memory (the
	 * stream don't remain opened and other applications can use the file).
	 */
	private void open() {
		File[] files = null;
		fileChooser.setMultiSelectionEnabled(true);
		try {
			if (fileChooser.open(this) == JFileChooser.APPROVE_OPTION) {
				files = fileChooser.getSelectedFiles();

				for (File file2 : files) {
					open(file2.getPath(), true);
				}
			}
		} catch (FileNotFoundException e) {
			JOptionPane.showMessageDialog(this,
					STRINGS.getProperty("cant-find") + " " + e.getMessage(),
					STRINGS.getProperty("error"), JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}

	/**
	 * Open a file and add the content to a new {@link TextArea}. The main
	 * difference between {@link #open()} and this is that this method receive,
	 * by passing an argument, the path of the file to be opened, instead of
	 * showing the {@code fileChooser}. This method doesn't show any kind of
	 * dialog, even in case of an error.
	 * 
	 * @param path
	 *            The path of the file to be opened
	 * @param popupErrorMessages
	 *            Case <code>true</code>, it shows error messages for I/O
	 *            exceptions, etc. Case <code>false</code>, it runs on
	 *            "silent mode"
	 */
	private void open(String path, boolean popupErrorMessages) {
		// Check if the document is already opened
		int index;
		if ((index = isOpened(path)) != -1) {
			tabs.setSelectedIndex(index);
			return;
		}

		try {
			String[] file = fileStreamer.open(path);
			tabs.addTab(file[0], path, file[2]);
			if (tabs.getSelectedComponent().getTextDocument().isNewDocument()) {
				tabs.remove(tabs.getSelectedIndex());
			}
			tabs.setSelectedIndex(tabs.getComponentCount() - 1);
			updateTile();
		} catch (FileNotFoundException e) {
			if (popupErrorMessages) {
				JOptionPane
						.showMessageDialog(this,
								STRINGS.getProperty("cant-find") + " " + path,
								STRINGS.getProperty("error"),
								JOptionPane.ERROR_MESSAGE);
			}

			e.printStackTrace();
		} catch (IOException e) {
			if (popupErrorMessages) {
				JOptionPane
						.showMessageDialog(this,
								STRINGS.getProperty("Not able to open") + " "
										+ path, STRINGS.getProperty("error"),
								JOptionPane.ERROR_MESSAGE);
			}
			e.printStackTrace();
		}
	}

	private void preferences() {
		new PreferencesDialog(this).setVisible(true);
	}

	/**
	 * Saves the current document. If file is not {@code savedOnDisk}, prompts
	 * the {@code fileChooser} to select the destination file. If it's already
	 * on disk, it only overwrites it.
	 * 
	 * @return <code>true</code> in case of the document was successfully saved
	 */
	private boolean save() {
		TextArea textArea = tabs.getSelectedComponent();
		if (!textArea.getTextDocument().isSavedOnDisk()) {
			return saveAs();
		} else {
			try {
				new TextFileStreamer().save(textArea.getText(), textArea
						.getTextDocument().getPath());
				textArea.getTextDocument().setSaved(true);
				textArea.getTextDocument().setSavedOnDisk(true);
				tabs.setTitleStarAt(tabs.getSelectedIndex(), false);
				return true;
			} catch (IOException e) {
				String path = textArea.getTextDocument().getPath() != null ? textArea
						.getTextDocument().getPath() : textArea
						.getTextDocument().getName();
				JOptionPane.showMessageDialog(this,
						STRINGS.getProperty("occurred-an-error-saving") + " "
								+ path, STRINGS.getProperty("error"),
						JOptionPane.ERROR_MESSAGE);
				e.printStackTrace();
			}
		}
		return false;
	}

	/**
	 * This method class save methods to all opened documents. If
	 * {@link ActionListener} save method returns false, saveAll returns too.
	 */
	private void saveAll() {
		Component[] components = tabs.getComponents();
		for (int i = 0; i < components.length; i++) {
			tabs.setSelectedIndex(i);
			if (!save()) {
				return;
			}
		}
	}

	/**
	 * Saves the current document. It prompts the {@code fileChooser} to select
	 * the destination file.
	 * 
	 * @return <code>true</code> in case of the document was successfully saved
	 */
	private boolean saveAs() {
		TextArea textArea = tabs.getSelectedComponent();
		if (fileChooser.save(this) == JFileChooser.APPROVE_OPTION) {
			File file = null;
			try {
				file = fileChooser.getSelectedFile();
				// Flushes the content
				fileStreamer.save(tabs.getSelectedComponent().getText(), file);
				TextDocument doc = textArea.getTextDocument();
				doc.setName(file.getName());
				doc.setPath(file.getPath());
				doc.setSaved(true);
				doc.setSavedOnDisk(true);
				updateTile();
				tabs.setTitleStarAt(tabs.getSelectedIndex(), false);
				return true;
			} catch (IOException e) {
				String path = textArea.getTextDocument().getPath() != null ? textArea
						.getTextDocument().getPath() : textArea
						.getTextDocument().getName();
				JOptionPane.showMessageDialog(this,
						STRINGS.getProperty("occurred-an-error-saving") + " "
								+ path, STRINGS.getProperty("error"),
						JOptionPane.ERROR_MESSAGE);
				e.printStackTrace();
			}
		}
		return false;
	}

	/**
	 * Changes the title of ZephyrUI based on the current document.
	 */
	private void tabChanged() {
		TextArea textArea = tabs.getSelectedComponent();
		updateTile();
		// Workaround
		if (!textArea.getTextDocument().isSaved()) {
			tabs.setTitleStarAt(tabs.getSelectedIndex(), true);
		}
	}

	/**
	 * Updates the frame title based on selected document, on the format "
	 * document name - document path - Zephyr".
	 */
	private void updateTile() {
		String docName = tabs.getSelectedComponent().getTextDocument()
				.getName();
		String docPath = tabs.getSelectedComponent().getTextDocument()
				.getPath();
		if (docPath == null) {
			setTitle(docName + " - Zephyr");
		} else {
			setTitle(docName
					+ " - "
					+ docPath.substring(0, docPath.lastIndexOf(System
							.getProperty("file.separator")) + 1) + " - Zephyr");
		}

		try {
			tabs.setTitleAt(tabs.getSelectedIndex(), docName);
		} catch (ArrayIndexOutOfBoundsException e) {
			e.printStackTrace();
		}
	}
}
