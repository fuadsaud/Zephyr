package zephyr.ui;

import static zephyr.Zephyr.PREFERENCES;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JTextArea;

import zephyr.Zephyr;
import zephyr.text.TextDocument;

public class TextArea extends JTextArea {

	/**
	 * Serial version ID.
	 */
	private static final long serialVersionUID = 2233198146436091347L;

	public TextArea() {
		super(new TextDocument());

		init();
	}

	public TextArea(String name, String path, String content) {
		super(new TextDocument(name, path, content));

		init();
	}

	/**
	 * This methods works just like {@link JTextArea#getDocument()}, but casts
	 * the return type to {@link TextDocument}.
	 * 
	 * @return the casted document
	 */
	public TextDocument getTextDocument() {
		return (TextDocument) super.getDocument();
	}

	private void init() {
		setTabSize(4);
		setLineWrap(true);
		int fontSize;
		try {
			fontSize = Integer.parseInt(PREFERENCES.getProperty("font-size"));
		} catch (NumberFormatException e) {
			fontSize = Integer.parseInt(Zephyr.DEFAULT_PROPERTIES
					.getProperty("font-size"));
			e.printStackTrace();
		}
		setFont(new Font("Courier New", Font.PLAIN, fontSize));
		setForeground(Color.BLACK);
	}
}
