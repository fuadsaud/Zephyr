package zephyr;

import zephyr.ui.ZephyrUI;

public class PreferencesManager {

	private final ZephyrUI ui;

	public PreferencesManager(ZephyrUI ui) {
		this.ui = ui;

	}

	public void setAlwaysOnTop(boolean alwaysOnTop) {
		ui.setAlwaysOnTop(alwaysOnTop);
	}
}
