package zephyr.ui;

import static zephyr.Zephyr.PREFERENCES;
import static zephyr.Zephyr.STRINGS;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayDeque;

import javax.swing.ButtonGroup;
import javax.swing.ButtonModel;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.KeyStroke;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;
import javax.swing.undo.UndoManager;

import zephyr.Zephyr;
import zephyr.file.TextFileStreamer;
import zephyr.text.TextDocument;
import zephyr.ui.components.GenericScrollPane;
import zephyr.ui.components.TextArea;
import zephyr.ui.components.TextAreaTabbedPane;
import zephyr.ui.dialogs.AboutDialog;
import zephyr.ui.dialogs.FileChooser;
import zephyr.ui.dialogs.FindDialog;
import zephyr.ui.dialogs.PreferencesDialog;

/**
 * @author Fuad Saud
 * 
 */
public class ZephyrUI extends JFrame {

	/**
	 * Serial version ID.
	 */
	private static final long serialVersionUID = 3220666579206122227L;

	/**
	 * The text area's tabs pane.
	 */
	private final TextAreaTabbedPane tabs = new TextAreaTabbedPane();

	/**
	 * A {@link JFileChooser} to manage the open and save actions.
	 */
	private final FileChooser fileChooser = new FileChooser();

	/**
	 * A simple file manager to handle streams and low level file treatment.
	 */
	private final TextFileStreamer fileStreamer = new TextFileStreamer();

	/**
	 * The dialog for showing find options.
	 */
	private FindDialog findDialog = null;

	private ArrayDeque<String> recentDocumentsPaths = new ArrayDeque<String>(10);

	private JMenu recentDocumentsMenu;

	/**
	 * Initializes ZephyrUI and loads documents from previous sessions.
	 */
	public ZephyrUI() {
		loadRecentDocuments();
		initComponents();
		loadPreviousSession();
		updateTitle();
	}

	/**
	 * Initializes ZephyrUI and try to open files based on the <code>args</code>
	 * , an array of paths. If <code>args.length == 0</code>, open documents
	 * from last session.
	 * 
	 * @param args
	 *            The paths of the files to be open
	 */
	public ZephyrUI(String[] args) {
		this();
		if (args != null)
			// Open command line arguments
			for (int i = 0; i < args.length; i++) {
				if (args[i] != null) {
					open(args[i], true);
				}
			}
	}

	/**
	 * Pop up an {@link AboutDialog}.
	 */
	private void about() {
		new AboutDialog(this).setVisible(true);
	}

	private void addRecentDocumentsPath(String path) {
		if (recentDocumentsPaths.contains(path)) {
			recentDocumentsPaths.remove(path);
		}
		recentDocumentsPaths.addFirst(path);
		updateRecentDocumentsMenu();
	}

	/**
	 * Close the selected document, prompting the user in case of the file is
	 * not saved.
	 * 
	 * @return <code>true</code> if the document was successfully closed
	 */
	private boolean close() {
		TextArea textArea = tabs.getSelectedComponent();
		if (!textArea.getTextDocument().isSaved()) {
			String path = textArea.getTextDocument().getPath() != null ? textArea
					.getTextDocument().getPath() : textArea.getTextDocument().getName();
			int opcao = JOptionPane.showConfirmDialog(this,
					STRINGS.getProperty("save-changes") + " " + path + "?",
					STRINGS.getProperty("close"), JOptionPane.YES_NO_CANCEL_OPTION,
					JOptionPane.QUESTION_MESSAGE);
			if (opcao == JOptionPane.YES_OPTION) {
				save();
			} else if (opcao == JOptionPane.CANCEL_OPTION) {
				return false;
			}
		}

		if (tabs.getComponents().length == 1) {
			newDocument();
			tabs.remove(0);
		} else {
			tabs.remove(tabs.getSelectedIndex());
		}
		return true;
	}

	/**
	 * Closes all open documents and saves the current session on the "session"
	 * file.
	 * 
	 * @return <code>true</code> if all documents were successfully closed
	 */
	private boolean closeAll() {
		for (int i = tabs.getComponentCount() - 1; i >= 0; i--) {
			tabs.setSelectedIndex(i);
			if (!close()) {
				return false;
			}
		}
		return true;
	}

	private boolean closeAllOthers() {
		int current = tabs.getSelectedIndex();
		for (int i = tabs.getComponentCount() - 1; i >= 0; i--) {
			tabs.setSelectedIndex(i);
			if (tabs.getSelectedIndex() != current) {
				if (!close()) {
					return false;
				}
			}
		}
		return true;
	}

	private boolean closeAllToTheRight() {
		int current = tabs.getSelectedIndex();
		for (int i = tabs.getComponentCount() - 1; i > current; i--) {
			tabs.setSelectedIndex(i);
			if (tabs.getSelectedIndex() != current) {
				if (!close()) {
					return false;
				}
			}
		}
		return true;
	}

	/**
	 * Closes all open documents and calls {@linkplain Zephyr#shutdown()};
	 */
	private void exit() {
		// Current session
		boolean rememberCurrentSession = Boolean.parseBoolean(PREFERENCES
				.getProperty("remember-current-session"));

		if (rememberCurrentSession) {
			StringBuilder paths = new StringBuilder();
			for (int i = tabs.getComponentCount() - 1; i >= 0; i--) {
				tabs.setSelectedIndex(i);
				if (tabs.getSelectedComponent().getTextDocument().getPath() != null) {
					paths.append(tabs.getSelectedComponent().getTextDocument().getPath() + ";");
				}
			}
			if (paths.toString() != null && !paths.toString().isEmpty()) {
				PREFERENCES.setProperty("session", paths.toString());
			}
		}

		// Close process
		if (closeAll()) {
			// Recent documents
			if (!recentDocumentsPaths.isEmpty()) {
				StringBuilder recentPaths = new StringBuilder();
				for (String path : recentDocumentsPaths) {
					recentPaths.append(path + ";");
				}
				PREFERENCES.setProperty("recent-documents", recentPaths.toString());
			}
			PREFERENCES.setProperty("line-separator",
					Zephyr.lineSeparatorAlias(getCastedMenuBar().getSelectedLineSeparator()));

			Zephyr.shutdown();
		}
	}

	private void find() {
		if (findDialog == null) {
			findDialog = new FindDialog(this, tabs.getSelectedComponent());
			findDialog.addWindowListener(new WindowListener() {

				@Override
				public void windowActivated(WindowEvent e) {

				}

				@Override
				public void windowClosed(WindowEvent e) {

				}

				@Override
				public void windowClosing(WindowEvent e) {
					findDialog = null;
				}

				@Override
				public void windowDeactivated(WindowEvent e) {

				}

				@Override
				public void windowDeiconified(WindowEvent e) {

				}

				@Override
				public void windowIconified(WindowEvent e) {

				}

				@Override
				public void windowOpened(WindowEvent e) {

				}
			});
			findDialog.setVisible(true);
		}
	}

	private MenuBar getCastedMenuBar() {
		return (MenuBar) getJMenuBar();
	}

	/**
	 * Initializes all the components in the frame.
	 */
	private void initComponents() {
		initMenuBar();
		initTabs();

		addWindowListener(new WindowListener() {

			@Override
			public void windowActivated(WindowEvent arg0) {

			}

			@Override
			public void windowClosed(WindowEvent arg0) {

			}

			@Override
			public void windowClosing(WindowEvent arg0) {
				exit();

			}

			@Override
			public void windowDeactivated(WindowEvent arg0) {

			}

			@Override
			public void windowDeiconified(WindowEvent arg0) {

			}

			@Override
			public void windowIconified(WindowEvent arg0) {

			}

			@Override
			public void windowOpened(WindowEvent arg0) {

			}
		});

		addKeyListener(new KeyListener() {

			@Override
			public void keyPressed(KeyEvent e) {
				if (e.isShiftDown()) {
					System.out.println("foi");
					int sizeAmount = 50;
					if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
						Dimension d = getSize();
						setSize(d.width + sizeAmount, d.height);
					} else if (e.getKeyCode() == KeyEvent.VK_LEFT) {
						Dimension d = getSize();
						setSize(d.width - sizeAmount, d.height);
					} else if (e.getKeyCode() == KeyEvent.VK_DOWN) {
						Dimension d = getSize();
						setSize(d.width, d.height + sizeAmount);
					} else if (e.getKeyCode() == KeyEvent.VK_UP) {
						Dimension d = getSize();
						setSize(d.width, d.height - sizeAmount);
					}
				}
			}

			@Override
			public void keyReleased(KeyEvent e) {

			}

			@Override
			public void keyTyped(KeyEvent e) {

			}
		});
		setIconImage(Toolkit.getDefaultToolkit().getImage(
				this.getClass().getResource(Zephyr.IMAGES + "zephyr.png")));
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		setSize(480, 600);
		setLocation(250, 150);
		setAlwaysOnTop(Boolean.parseBoolean(PREFERENCES.getProperty("keep-window-on-top")));
		newDocument();
	}

	/**
	 * Initializes the {@code menuBar}.
	 */
	private void initMenuBar() {

		setJMenuBar(new MenuBar());
	}

	/**
	 * Initializes the {@code tabs}.
	 */
	private void initTabs() {
		tabs.addChangeListener(new ChangeListener() {

			@Override
			public void stateChanged(ChangeEvent e) {
				tabChanged();
			}
		});
		tabs.addMouseListener(new MouseListener() {

			@Override
			public void mouseClicked(MouseEvent e) {
				if (e.getButton() == MouseEvent.BUTTON2) {
					close();
				} else if (e.getButton() == MouseEvent.BUTTON1 && e.getClickCount() == 2) {
					newDocument();
				}
			}

			@Override
			public void mouseEntered(MouseEvent e) {

			}

			@Override
			public void mouseExited(MouseEvent e) {

			}

			@Override
			public void mousePressed(MouseEvent e) {

			}

			@Override
			public void mouseReleased(MouseEvent e) {

			}
		});
		getContentPane().add(tabs);
	}

	/**
	 * This methods checks if a document is already open in the application,
	 * based on file's path.
	 * 
	 * @param path
	 *            The file path to be checked
	 * @return the index of the text area on the <code>tabs</code> or -1, case
	 *         not open
	 */
	@SuppressWarnings("unchecked")
	private int isOpen(String path) {
		Component[] components = tabs.getComponents();

		for (int i = 0; i < components.length; i++) {
			String path1 = ((GenericScrollPane<TextArea>) components[i]).getComponent()
					.getTextDocument().getPath();
			if (path.equals(path1)) {
				return i;
			}
		}
		return -1;
	}

	/**
	 * Open the documents from previous sessions, based on the "session" file.
	 */
	private void loadPreviousSession() {
		String session = Zephyr.PREFERENCES.getProperty("session");
		if (session != null) {
			String[] paths = session.split(";");
			for (int i = paths.length - 1; i >= 0; i--) {
				if (!paths[i].isEmpty()) {
					open(paths[i], false);
				}
			}
		}
	}

	private void loadRecentDocuments() {
		String recentPaths = PREFERENCES.getProperty("recent-documents");
		if (recentPaths != null && !recentPaths.isEmpty()) {
			String[] paths = recentPaths.split(";");
			for (String path : paths) {
				recentDocumentsPaths.addLast(path);
			}
		}
	}

	/**
	 * Creates a new tab with a blank {@link TextArea}.
	 */
	private void newDocument() {
		tabs.addTab();
		tabs.setSelectedIndex(tabs.getComponentCount() - 1);
	}

	/**
	 * Shows the {@code fileChooser} and creates a new tab and a document with
	 * the content of the chosen file. The content is copied to the memory (the
	 * stream don't remain open and other applications can use the file).
	 */
	private void open() {
		File[] files = null;
		fileChooser.setMultiSelectionEnabled(true);
		try {
			if (fileChooser.open(this) == JFileChooser.APPROVE_OPTION) {
				files = fileChooser.getSelectedFiles();

				for (File file2 : files) {
					open(file2.getPath(), true);
				}
			}
		} catch (FileNotFoundException e) {
			showErrorMessage(STRINGS.getProperty("cant-find") + " " + e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * Open a file and add the content to a new {@link TextArea}. The main
	 * difference between {@link #open()} and this is that this method receive,
	 * by passing an argument, the path of the file to be open, instead of
	 * showing the {@code fileChooser}. This method doesn't show any kind of
	 * dialog, even in case of an error.
	 * 
	 * @param path
	 *            The path of the file to be open
	 * @param popupErrorMessages
	 *            Case <code>true</code>, it shows error messages for I/O
	 *            exceptions, etc. Case <code>false</code>, it runs on
	 *            "silent mode"
	 */
	private void open(String path, boolean popupErrorMessages) {
		// Check if the document is already open
		int index;
		if ((index = isOpen(path)) != -1) {
			tabs.setSelectedIndex(index);
			return;
		}

		try {
			TextDocument doc = fileStreamer.open(path);
			path = doc.getPath();
			tabs.addTab(doc);
			if (tabs.getSelectedComponent().getTextDocument().isNewDocument()) {
				tabs.remove(tabs.getSelectedIndex());
			}
			tabs.setSelectedIndex(tabs.getComponentCount() - 1);
			updateTitle();
			addRecentDocumentsPath(path);
		} catch (FileNotFoundException e) {
			if (popupErrorMessages) {
				showErrorMessage(STRINGS.getProperty("cant-find") + " " + path);
			}
			e.printStackTrace();
		} catch (IOException e) {
			if (popupErrorMessages) {
				showErrorMessage(STRINGS.getProperty("not-able-to-open") + " " + path);
			}
			e.printStackTrace();
		}
	}

	/**
	 * Shows the preferences dialog.
	 */
	private void preferences() {
		new PreferencesDialog(this).setVisible(true);
	}

	/**
	 * Saves the current document. If file is not {@code savedOnDisk}, prompts
	 * the {@code fileChooser} to select the destination file. If it's already
	 * on disk, it only overwrites it.
	 * 
	 * @return <code>true</code> in case of the document was successfully saved
	 */
	private boolean save() {
		TextArea textArea = tabs.getSelectedComponent();
		if (!textArea.getTextDocument().isSavedOnDisk()) {
			return saveAs();
		} else {
			try {
				fileStreamer.save(textArea.getText(), textArea.getTextDocument().getPath());
				textArea.getTextDocument().setSaved(true);
				textArea.getTextDocument().setSavedOnDisk(true);
				tabs.setTitleStarAt(tabs.getSelectedIndex(), false);
				return true;
			} catch (IOException e) {
				String path = textArea.getTextDocument().getPath() != null ? textArea
						.getTextDocument().getPath() : textArea.getTextDocument().getName();
				showErrorMessage(STRINGS.getProperty("occurred-an-error-saving") + " " + path);
				e.printStackTrace();
			}
		}
		return false;
	}

	/**
	 * This method class save methods to all open documents. If
	 * {@link ActionListener} save method returns false, saveAll returns too.
	 */
	private void saveAll() {
		Component[] components = tabs.getComponents();
		for (int i = 0; i < components.length; i++) {
			tabs.setSelectedIndex(i);
			if (!save()) {
				return;
			}
		}
	}

	/**
	 * Saves the current document. It prompts the {@code fileChooser} to select
	 * the destination file.
	 * 
	 * @return <code>true</code> in case of the document was successfully saved
	 */
	private boolean saveAs() {
		TextArea textArea = tabs.getSelectedComponent();
		if (fileChooser.save(this) == JFileChooser.APPROVE_OPTION) {
			File file = null;
			try {
				file = fileChooser.getSelectedFile();
				// Flushes the content
				fileStreamer.save(tabs.getSelectedComponent().getText(), file);
				TextDocument doc = textArea.getTextDocument();
				doc.setName(file.getName());
				doc.setPath(file.getPath());
				doc.setSaved(true);
				doc.setSavedOnDisk(true);
				updateTitle();
				tabs.setTitleStarAt(tabs.getSelectedIndex(), false);
				addRecentDocumentsPath(file.getPath());
				return true;
			} catch (IOException e) {
				String path = textArea.getTextDocument().getPath() != null ? textArea
						.getTextDocument().getPath() : textArea.getTextDocument().getName();
				showErrorMessage(STRINGS.getProperty("occurred-an-error-saving") + " " + path);
				e.printStackTrace();
			}
		}
		return false;
	}

	/**
	 * Displays a message on an error-type {@link JOptionPane}.
	 * 
	 * @param message
	 */
	private void showErrorMessage(String message) {
		JOptionPane.showMessageDialog(this, message, STRINGS.getProperty("error"),
				JOptionPane.ERROR_MESSAGE);
	}

	/**
	 * Changes the title of ZephyrUI based on the current document.
	 */
	private void tabChanged() {
		TextArea textArea = tabs.getSelectedComponent();
		updateTitle();
		// Workaround
		if (!textArea.getTextDocument().isSaved()) {
			tabs.setTitleStarAt(tabs.getSelectedIndex(), true);
		}
	}

	/**
	 * Update the recent documents menu item, on the menu bar. The documents
	 * paths are retrieved from <code>recentDocumentsPaths</code>.
	 */
	private void updateRecentDocumentsMenu() {
		int count = recentDocumentsMenu.getMenuComponentCount();
		for (int i = 3; i < count; i++) {
			recentDocumentsMenu.remove(3);
		}
		if (recentDocumentsPaths.isEmpty()) {
			recentDocumentsMenu.setVisible(false);
		} else {
			recentDocumentsMenu.setVisible(true);

			for (String path : recentDocumentsPaths) {
				final JMenuItem pathMenuItem = new JMenuItem(path);
				pathMenuItem.addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
						open(pathMenuItem.getText(), true);
					}
				});

				recentDocumentsMenu.add(pathMenuItem);
			}
		}
	}

	/**
	 * Updates the frame title based on selected document, on the format "
	 * document name - document path - Zephyr".
	 */
	private void updateTitle() {
		String docName = tabs.getSelectedComponent().getTextDocument().getName();
		String docPath = tabs.getSelectedComponent().getTextDocument().getPath();
		if (docPath == null) {
			setTitle(docName + " - Zephyr");
		} else {
			setTitle(docName
					+ " - "
					+ docPath.substring(0,
							docPath.lastIndexOf(System.getProperty("file.separator")) + 1)
					+ " - Zephyr");
		}

		try {
			tabs.setTitleAt(tabs.getSelectedIndex(), docName);
		} catch (ArrayIndexOutOfBoundsException e) {
			e.printStackTrace();
		}
	}

	private class MenuBar extends JMenuBar {

		/**
		 * Serial version ID.
		 */
		private static final long serialVersionUID = -5235397452222826439L;

		private ButtonGroup lineSeparatorGroup;

		private JRadioButtonMenuItem caretReturnLineFeed;

		private JRadioButtonMenuItem caretReturn;

		private JRadioButtonMenuItem lineFeed;

		public MenuBar() {
			lineSeparatorGroup = new ButtonGroup();

			initMenus();
		}

		private String getSelectedLineSeparator() {
			if (caretReturn.isSelected()) {
				return "\r";
			}

			if (caretReturnLineFeed.isSelected()) {
				return "\r\n";
			}

			return "\n";
		}

		private void initEditMenu() {
			JMenu edit = new JMenu(STRINGS.getProperty("edit"));

			JMenuItem undo = new JMenuItem(STRINGS.getProperty("undo"));
			undo.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					try {
						((UndoManager) tabs.getSelectedComponent().getTextDocument()
								.getUndoableEditListeners()[0]).undo();
					} catch (CannotUndoException ex) {
						ex.printStackTrace();
					}
				}
			});
			undo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Z, KeyEvent.CTRL_DOWN_MASK));
			edit.add(undo);

			JMenuItem redo = new JMenuItem(STRINGS.getProperty("redo"));
			redo.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					try {
						((UndoManager) tabs.getSelectedComponent().getTextDocument()
								.getUndoableEditListeners()[0]).redo();
					} catch (CannotRedoException ex) {
						ex.printStackTrace();
					}
				}
			});
			redo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Z, KeyEvent.CTRL_DOWN_MASK
					+ KeyEvent.SHIFT_DOWN_MASK));
			edit.add(redo);

			edit.addSeparator();

			JMenuItem find = new JMenuItem(STRINGS.getProperty("find") + "...");
			find.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					find();
				}
			});
			find.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F, KeyEvent.CTRL_DOWN_MASK));
			edit.add(find);

			edit.addSeparator();

			JMenu lineSeparator = new JMenu(STRINGS.getProperty("line-separator"));

			lineFeed = new JRadioButtonMenuItem(STRINGS.getProperty("line-feed"));
			lineSeparator.add(lineFeed);

			caretReturn = new JRadioButtonMenuItem(STRINGS.getProperty("caret-return"));
			lineSeparator.add(caretReturn);

			caretReturnLineFeed = new JRadioButtonMenuItem(
					STRINGS.getProperty("line-feed-caret-return"));
			lineSeparator.add(caretReturnLineFeed);

			lineSeparatorGroup.add(lineFeed);
			lineSeparatorGroup.add(caretReturn);
			lineSeparatorGroup.add(caretReturnLineFeed);

			// Defines which button set selected, based on preferences.
			String ls = Zephyr.lineSeparator();
			ButtonModel buttonModel;
			if (ls.equals("\r\n")) {
				buttonModel = caretReturnLineFeed.getModel();
			} else if (ls.equals("\r")) {
				buttonModel = caretReturn.getModel();
			} else {
				buttonModel = lineFeed.getModel();
			}

			lineSeparatorGroup.setSelected(buttonModel, true);

			edit.add(lineSeparator);

			edit.addSeparator();

			JMenuItem preferences = new JMenuItem(STRINGS.getProperty("preferences") + "...");
			preferences.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					preferences();
				}
			});
			preferences.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_SPACE,
					KeyEvent.CTRL_DOWN_MASK));
			edit.add(preferences);

			add(edit);
		}

		private void initFileMenu() {
			JMenu file = new JMenu(STRINGS.getProperty("file"));

			JMenuItem newDocument = new JMenuItem(STRINGS.getProperty("new"));
			newDocument.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					newDocument();
				}
			});
			newDocument.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N,
					KeyEvent.CTRL_DOWN_MASK));
			file.add(newDocument);

			JMenuItem open = new JMenuItem(STRINGS.getProperty("open") + "...");
			open.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					open();
				}
			});
			open.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, KeyEvent.CTRL_DOWN_MASK));
			file.add(open);

			file.addSeparator();

			JMenuItem save = new JMenuItem(STRINGS.getProperty("save"));
			save.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					save();
				}
			});
			save.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, KeyEvent.CTRL_DOWN_MASK));
			file.add(save);

			JMenuItem saveAs = new JMenuItem(STRINGS.getProperty("save-as") + "...");
			saveAs.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					saveAs();
				}
			});
			saveAs.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,
					KeyEvent.CTRL_DOWN_MASK + KeyEvent.ALT_DOWN_MASK));
			file.add(saveAs);

			JMenuItem saveAll = new JMenuItem(STRINGS.getProperty("save-all"));
			saveAll.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					saveAll();
				}
			});
			saveAll.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,
					KeyEvent.CTRL_DOWN_MASK + KeyEvent.SHIFT_DOWN_MASK));
			file.add(saveAll);

			file.addSeparator();

			JMenuItem close = new JMenuItem(STRINGS.getProperty("close"));
			close.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					close();
				}
			});
			close.setAccelerator(KeyStroke
					.getKeyStroke(KeyEvent.VK_W, KeyEvent.CTRL_DOWN_MASK));
			file.add(close);

			JMenuItem closeAll = new JMenuItem(STRINGS.getProperty("close-all"));
			closeAll.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					closeAll();
				}
			});
			closeAll.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_W,
					KeyEvent.CTRL_DOWN_MASK + KeyEvent.ALT_DOWN_MASK));
			file.add(closeAll);

			JMenuItem closeAllOthers = new JMenuItem(STRINGS.getProperty("close-all-others"));
			closeAllOthers.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					closeAllOthers();
				}
			});
			closeAllOthers.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_W,
					KeyEvent.CTRL_DOWN_MASK + KeyEvent.SHIFT_DOWN_MASK));
			file.add(closeAllOthers);

			JMenuItem closeAllToTheRight = new JMenuItem(
					STRINGS.getProperty("close-all-to-the-right"));
			closeAllToTheRight.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					closeAllToTheRight();
				}
			});
			closeAllToTheRight.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_W,
					KeyEvent.CTRL_DOWN_MASK + KeyEvent.SHIFT_DOWN_MASK
							+ KeyEvent.ALT_DOWN_MASK));
			file.add(closeAllToTheRight);

			file.addSeparator();

			recentDocumentsMenu = new JMenu(STRINGS.getProperty("recent"));

			JMenuItem openAllRecent = new JMenuItem(STRINGS.getProperty("open-all-recent"));
			openAllRecent.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					for (String path : recentDocumentsPaths) {
						open(path, true);
					}
				}
			});

			JMenuItem emptyRecent = new JMenuItem(STRINGS.getProperty("empty-recent"));
			emptyRecent.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					recentDocumentsPaths.clear();
					updateRecentDocumentsMenu();
				}
			});

			recentDocumentsMenu.add(openAllRecent);
			recentDocumentsMenu.add(emptyRecent);

			recentDocumentsMenu.addSeparator();

			updateRecentDocumentsMenu();
			file.add(recentDocumentsMenu);

			file.addSeparator();

			JMenuItem exit = new JMenuItem(STRINGS.getProperty("exit"));
			exit.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					exit();
				}
			});
			exit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F4, KeyEvent.ALT_DOWN_MASK));
			file.add(exit);

			add(file);
		}

		private void initHelpMenu() {
			JMenu help = new JMenu(STRINGS.getProperty("help"));

			JMenuItem about = new JMenuItem(STRINGS.getProperty("about-zephyr") + "...");
			about.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					about();
				}
			});
			about.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0));
			help.add(about);

			add(help);
		}

		private void initMenus() {
			initFileMenu();
			initEditMenu();
			initViewMenu();
			initHelpMenu();
		}

		private void initViewMenu() {
			JMenu view = new JMenu(STRINGS.getProperty("view"));

			add(view);
		}
	}
}
