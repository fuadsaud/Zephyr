package zephyr.ui.components;

import static zephyr.Zephyr.DEFAULT_PREFERENCES;
import static zephyr.Zephyr.PREFERENCES;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JTextArea;

import zephyr.Zephyr;
import zephyr.text.TextDocument;

/**
 * 
 * @see JTextArea
 * 
 * @author Fuad Saud
 * 
 */
public class TextArea extends JTextArea {

	/**
	 * Serial version ID.
	 */
	private static final long serialVersionUID = 2233198146436091347L;

	public TextArea() {
		this(new TextDocument());
	}

	public TextArea(TextDocument document) {
		super(document);

		init();
	}

	/**
	 * This methods works just like {@link JTextArea#getDocument()}, but casts
	 * the return type to {@link TextDocument}.
	 * 
	 * @return the casted document
	 */
	public TextDocument getTextDocument() {
		return (TextDocument) super.getDocument();
	}

	private void init() {
		try {
			setTabSize(Integer.parseInt(PREFERENCES.getProperty("tab-size")));
		} catch (NumberFormatException e) {
			setTabSize(Integer.parseInt(DEFAULT_PREFERENCES.getProperty("tab-size")));
			e.printStackTrace();
		}
		setLineWrap(true);
		int fontSize;
		try {
			fontSize = Integer.parseInt(PREFERENCES.getProperty("font-size"));
		} catch (NumberFormatException e) {
			fontSize = Integer.parseInt(Zephyr.DEFAULT_PREFERENCES.getProperty("font-size"));
			e.printStackTrace();
		}
		setFont(new Font("Courier New", Font.PLAIN, fontSize));
		setForeground(Color.BLACK);

		addKeyListener(new KeyListener() {

			@Override
			public void keyPressed(KeyEvent e) {
				if (e.isAltDown()) {
					if (e.getKeyCode() == KeyEvent.VK_UP) {
						swithLinesUp();
					} else if (e.getKeyCode() == KeyEvent.VK_DOWN) {
						switchLinesDown();
					}
				}
			}

			@Override
			public void keyReleased(KeyEvent e) {

			}

			@Override
			public void keyTyped(KeyEvent e) {

			}
		});
	}

	private void switchLinesDown() {
		int[] switchLinesDown = getTextDocument().switchLinesDown(getCaretPosition());
		if (switchLinesDown[0] != switchLinesDown[1]) {
			setSelectionStart(switchLinesDown[0]);
			setSelectionEnd(switchLinesDown[1]);
		}

	}

	private void swithLinesUp() {
		int[] switchLinesUp = getTextDocument().switchLinesUp(getCaretPosition());
		if (switchLinesUp[0] != switchLinesUp[1]) {
			setSelectionStart(switchLinesUp[0]);
			setSelectionEnd(switchLinesUp[1]);
		}
	}
}
