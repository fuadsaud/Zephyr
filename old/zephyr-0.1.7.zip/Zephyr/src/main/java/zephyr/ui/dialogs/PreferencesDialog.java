package zephyr.ui.dialogs;

import static zephyr.Zephyr.PREFERENCES;
import static zephyr.Zephyr.STRINGS;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTabbedPane;
import javax.swing.SpinnerNumberModel;
import javax.swing.UIManager;

import net.miginfocom.swing.MigLayout;
import zephyr.Zephyr;

/**
 * A dialog to set simple preferences.
 * 
 * @author Fuad Saud
 * 
 */

public class PreferencesDialog extends JDialog {

	/**
	 * Serial version ID
	 */
	private static final long serialVersionUID = 3252739958878696995L;

	/**
	 * A map containing LaF's classes names, based on the short name.
	 */
	private static final Map<String, String> lafs = new HashMap<String, String>();

	private static final Map<String, String> langs = new HashMap<String, String>();

	private static int lastOpenTab = 0;

	/**
	 * A {@link JTabbedPane} to organize the dialog.
	 */
	private JTabbedPane tabs;

	/**
	 * The panel containing appearance settings.
	 */
	private JPanel appearencePanel;

	/**
	 * The panel containing fonts settings.
	 */
	private JPanel editorPanel;

	/**
	 * The panel containing miscellaneous settings.
	 */
	private JPanel miscPanel;

	/**
	 * A combo box with the LaF options.
	 */
	private JComboBox<String> lafCombo;

	/**
	 * A combo box with language options.
	 */
	private JComboBox<String> langCombo;

	/**
	 * The {@link JTabbedPane} to separate settings by content.
	 */

	/**
	 * A {@link JSpinner} to set font size.
	 */
	private JSpinner fontSizeSpinner;

	private JComboBox<Integer> tabSizeCombo;

	/**
	 * A {@link JCheckBox} to set remember session property.
	 */
	private JCheckBox rememberSessionCheckBox;

	private JCheckBox keepOnTopCheckBox;

	static {
		lafs.put("Liquid", "com.birosoft.liquid.LiquidLookAndFeel");
		lafs.put("Metal", "javax.swing.plaf.metal.MetalLookAndFeel");
		lafs.put("Motif", "com.sun.java.swing.plaf.motif.MotifLookAndFeel");
		lafs.put("Nimbus", "javax.swing.plaf.nimbus.NimbusLookAndFeel");
		lafs.put("System", UIManager.getSystemLookAndFeelClassName());

		langs.put("English", "en-US");
		langs.put("Portugu�s do Brasil", "pt-BR");
	}

	/**
	 * Initializes the dialog.
	 * 
	 * @param owner
	 *            the Frame from which the dialog is displayed
	 */
	public PreferencesDialog(JFrame owner) {
		super(owner, STRINGS.getProperty("preferences"), true);

		initTabs();

		initAppearance();
		initEditor();
		initMisc();
		initButtons();

		setSize(600, 300);
		pack();
		setResizable(false);
		setLocationRelativeTo(owner);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);

		addWindowListener(new WindowListener() {

			@Override
			public void windowActivated(WindowEvent e) {

			}

			@Override
			public void windowClosed(WindowEvent e) {
				lastOpenTab = tabs.getSelectedIndex();
			}

			@Override
			public void windowClosing(WindowEvent e) {

			}

			@Override
			public void windowDeactivated(WindowEvent e) {

			}

			@Override
			public void windowDeiconified(WindowEvent e) {

			}

			@Override
			public void windowIconified(WindowEvent e) {

			}

			@Override
			public void windowOpened(WindowEvent e) {

			}
		});
	}

	/**
	 * Cancel action.
	 */
	private void cancel() {
		dispose();
	}

	/**
	 * Initialize appearance settings panel.
	 */
	private void initAppearance() {
		initLookAndFeel();
		initLanguage();
	}

	/**
	 * Initializes dialog's buttons.
	 */
	private void initButtons() {
		JPanel buttonsPanel = new JPanel(new MigLayout());

		buttonsPanel.add(new JLabel(STRINGS.getProperty("preferences-changes")),
				"skip, gap 20px");

		JButton ok = new JButton(STRINGS.getProperty("ok"));
		ok.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ok();
			}
		});
		buttonsPanel.add(ok, "newline push, skip 3, split, align right");

		JButton cancel = new JButton(STRINGS.getProperty("cancel"));
		cancel.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				cancel();
			}
		});

		buttonsPanel.add(cancel);

		add(buttonsPanel, BorderLayout.SOUTH);
	}

	/**
	 * Initializes the editor's settings panel.
	 */
	private void initEditor() {
		initFontSize();
		initTabSize();
	}

	private void initFontSize() {
		JLabel fontSizeLabel = new JLabel(STRINGS.getProperty("font-size"));
		fontSizeLabel.setToolTipText(STRINGS.getProperty("font-size-tooltip"));
		int fontSize;
		try {
			fontSize = Integer.parseInt(PREFERENCES.getProperty("font-size"));
		} catch (NumberFormatException e) {
			fontSize = Integer.parseInt(Zephyr.DEFAULT_PREFERENCES.getProperty("font-size"));
		}
		fontSizeSpinner = new JSpinner(new SpinnerNumberModel(fontSize, 8, 96, 1));
		editorPanel.add(fontSizeLabel);
		editorPanel.add(fontSizeSpinner);
	}

	private void initKeepOnTop() {
		keepOnTopCheckBox = new JCheckBox(STRINGS.getProperty("keep-window-on-top"));
		keepOnTopCheckBox.setToolTipText(STRINGS.getProperty("keep-window-on-top-tooltip"));
		keepOnTopCheckBox.setSelected(Boolean.parseBoolean(PREFERENCES
				.getProperty("keep-window-on-top")));
		miscPanel.add(keepOnTopCheckBox);
	}

	/**
	 * Initializes language options.
	 */
	private void initLanguage() {
		JLabel langLabel = new JLabel(STRINGS.getProperty("choose-language"));
		langLabel.setToolTipText(STRINGS.getProperty("choose-language-tooltip"));
		langCombo = new JComboBox<String>(new String[] { "English", "Portugu�s do Brasil" });
		langCombo.setSelectedItem(STRINGS.getProperty("language"));
		appearencePanel.add(langLabel);
		appearencePanel.add(langCombo);
	}

	/**
	 * Initializes look and feel's options.
	 */
	private void initLookAndFeel() {
		JLabel lafLabel = new JLabel(STRINGS.getProperty("choose-laf"));
		lafLabel.setToolTipText(STRINGS.getProperty("choose-laf-tooltip"));
		lafCombo = new JComboBox<String>(new String[] { "Liquid", "Metal", "Motif", "Nimbus",
				"System" });

		String name = UIManager.getLookAndFeel().getClass().getSimpleName()
				.replace("LookAndFeel", "");
		if (name.equals("Windows")) {
			name = "System";
		}
		lafCombo.setSelectedItem(name);
		appearencePanel.add(lafLabel);
		appearencePanel.add(lafCombo);
	}

	/**
	 * Initializes miscellaneous settings.
	 */
	private void initMisc() {
		initRememberSession();
		initKeepOnTop();
	}

	private void initRememberSession() {
		rememberSessionCheckBox = new JCheckBox(
				STRINGS.getProperty("remember-current-session"));
		rememberSessionCheckBox.setToolTipText(STRINGS
				.getProperty("remember-current-session-tooltip"));
		rememberSessionCheckBox.setSelected(Boolean.parseBoolean(PREFERENCES
				.getProperty("remember-current-session")));
		miscPanel.add(rememberSessionCheckBox);
	}

	/**
	 * Initializes the tab's panel.
	 */
	private void initTabs() {
		tabs = new JTabbedPane();

		appearencePanel = new JPanel(new MigLayout("wrap 2, gap 7px"));
		tabs.addTab(STRINGS.getProperty("appearance-settings"), appearencePanel);

		editorPanel = new JPanel(new MigLayout("wrap 2, gap 7px"));
		tabs.addTab(STRINGS.getProperty("editor-settings"), editorPanel);

		miscPanel = new JPanel(new MigLayout("wrap 1, gap 7px"));
		tabs.addTab(STRINGS.getProperty("misc-settings"), miscPanel);
		add(tabs, BorderLayout.CENTER);

		tabs.setSelectedIndex(lastOpenTab);
	}

	private void initTabSize() {
		JLabel tabSizeLabel = new JLabel(STRINGS.getProperty("tab-size"));
		tabSizeLabel.setToolTipText(STRINGS.getProperty("tab-size-tooltip"));
		int tabSize;
		try {
			tabSize = Integer.parseInt(PREFERENCES.getProperty("tab-size"));
		} catch (NumberFormatException e) {
			tabSize = Integer.parseInt(Zephyr.DEFAULT_PREFERENCES.getProperty("tab-size"));
		}
		tabSizeCombo = new JComboBox<Integer>(new Integer[] { 2, 3, 4, 8 });
		tabSizeCombo.setSelectedItem(new Integer(tabSize));
		editorPanel.add(tabSizeLabel);
		editorPanel.add(tabSizeCombo);
	}

	/**
	 * OK action.
	 */
	private void ok() {
		updateProperties();
		updatePreferences();
		dispose();
	}

	private void updatePreferences() {
		Zephyr.getPreferencesManager().setAlwaysOnTop(keepOnTopCheckBox.isSelected());
	}

	/**
	 * Updates the {@linkplain Zephyr#PREFERENCES}, based on the changes made.
	 */
	private void updateProperties() {
		PREFERENCES.setProperty("laf", lafs.get(lafCombo.getSelectedItem()));
		PREFERENCES.setProperty("language", langs.get(langCombo.getSelectedItem()));
		PREFERENCES.setProperty("font-size", fontSizeSpinner.getValue().toString());
		PREFERENCES.setProperty("tab-size", tabSizeCombo.getSelectedItem().toString());
		PREFERENCES.setProperty("remember-current-session",
				String.valueOf(rememberSessionCheckBox.isSelected()));
		PREFERENCES.setProperty("keep-window-on-top",
				String.valueOf(keepOnTopCheckBox.isSelected()));
	}
}
