package zephyr;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;
import java.util.Scanner;

import javax.swing.UIManager;

import zephyr.ui.SplashScreen;
import zephyr.ui.ZephyrUI;

/**
 * Bootstraps the application.
 * 
 * @author Fuad Saud
 * 
 */
public class Zephyr {

	/**
	 * Zephyr's version.
	 */
	public static final String VERSION = "0.1.8 Alpha";

	/**
	 * The project home page.
	 */
	public static final String HOME_PAGE = "http://twitter.com/fuadsaud";

	/**
	 * The product's license, including third party software's licenses.
	 */
	public static final String LICENSE;

	// Properties
	/**
	 * A default set of preferences.
	 */
	public static final Properties DEFAULT_PREFERENCES;

	/**
	 * User preferences. This properties are loaded from {@linkplain #SETTINGS}.
	 */
	public static final Properties PREFERENCES;

	/**
	 * All GUI messages and strings are defined by the language chosen by the
	 * user. The language files are stored in {@linkplain #LANGUAGES}.
	 */
	public static final Properties STRINGS;

	// Paths
	/**
	 * The resources package path.
	 */
	public static final String RESOURCES = "/";

	/**
	 * The images package path.
	 */
	public static final String IMAGES = RESOURCES + "images/";

	/**
	 * The language files package path.
	 */
	public static final String LANGUAGES = RESOURCES + "languages/";

	/**
	 * The settings file name.
	 */
	public static final String SETTINGS = "zephyr.properties";

	/**
	 * The splash screen.
	 */
	private static final SplashScreen SPLASH_SCREEN;

	/**
	 * The main GUI.
	 */
	private static ZephyrUI ui;

	private static PreferencesManager preferencesManager;

	/**
	 * A flag to indicates whether the application end loading (for disabling
	 * splash screen).
	 */
	private static boolean endLoading = false;

	static {
		// Initializes Properties
		DEFAULT_PREFERENCES = new Properties();
		PREFERENCES = new Properties(DEFAULT_PREFERENCES);
		STRINGS = new Properties();

		initDefaultProperties();
		initializeProperties();

		LICENSE = loadLicense();

		try {
			UIManager.setLookAndFeel(PREFERENCES.getProperty("laf"));
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		SPLASH_SCREEN = new SplashScreen();

		preferencesManager = new PreferencesManager(ui);
	}

	public static PreferencesManager getPreferencesManager() {
		return preferencesManager;
	}

	public static String lineSeparator() {
		String alias = PREFERENCES.getProperty("line-separator");
		String lineSeparator;
		if (alias.equalsIgnoreCase("CaretReturn/LineFeed"))
			lineSeparator = "\r\n";
		else if (alias.equalsIgnoreCase("CaretReturn"))
			lineSeparator = "\r";
		else
			lineSeparator = "\n";

		return lineSeparator;
	}

	public static String lineSeparatorAlias(String lineSeparator) {
		if (lineSeparator.equals("\r\n")) {
			return "CaretReturn/LineFeed";
		} else if (lineSeparator.equals("\r")) {
			return "CaretReturn";
		} else {
			return "LineFeed";
		}
	}

	/**
	 * @param args
	 *            Command line arguments.
	 */
	public static void main(final String[] args) {
		// Showing the splash screen
		Thread splashScreenThread = new Thread(new Runnable() {

			@Override
			public void run() {
				showSplashScreen();
			}
		});
		splashScreenThread.start();

		ui = new ZephyrUI(args);
		preferencesManager = new PreferencesManager(ui);

		// Holds the splash screen visible for a few seconds after the load
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		endLoading = true;

		ui.setVisible(true);
	}

	/**
	 * Stores properties files and exits.
	 */
	public static void shutdown() {
		try {
			FileWriter fw = new FileWriter(SETTINGS);
			PREFERENCES.store(fw, "Zephyr general settings");
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.exit(0);
	}

	private static void initDefaultProperties() {
		// Appearance properties
		DEFAULT_PREFERENCES.setProperty("laf", "javax.swing.plaf.metal.MetalLookAndFeel");
		DEFAULT_PREFERENCES.setProperty("language", "en-US");
		// Editor
		DEFAULT_PREFERENCES.setProperty("font-size", "15");
		DEFAULT_PREFERENCES.setProperty("tab-size", "4");
		// Misc
		DEFAULT_PREFERENCES.setProperty("remember-current-session", "true");
		DEFAULT_PREFERENCES.setProperty("keep-window-on-top", "false");
		// Encoding
		DEFAULT_PREFERENCES.setProperty("line-separator",
				lineSeparatorAlias(System.lineSeparator()));
	}

	/**
	 * Loads properties files.
	 */
	private static void initializeProperties() {
		try {
			// Initializes PREFERENCES
			File file = new File(SETTINGS);
			if (file.exists()) {
				FileReader fr = new FileReader(file);
				PREFERENCES.load(fr);
				fr.close();
			}

			// Initializes STRINGS
			STRINGS.load(Zephyr.class.getResourceAsStream(LANGUAGES
					+ PREFERENCES.getProperty("language")));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static String loadLicense() {
		// Reads up the license
		BufferedInputStream bis = new BufferedInputStream(
				Zephyr.class.getResourceAsStream(RESOURCES + "License.txt"));
		Scanner scanner = new Scanner(bis);
		StringBuilder builder = new StringBuilder();

		while (scanner.hasNextLine()) {
			builder.append(scanner.nextLine() + "\n");
		}

		return builder.toString();
	}

	/**
	 * Shows the splash screen until the loading is finished.
	 * 
	 */
	private static void showSplashScreen() {

		SPLASH_SCREEN.setVisible(true);
		int i = 0;
		while (!endLoading)
			while (i++ <= 100) {
				try {
					Thread.sleep(0);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				SPLASH_SCREEN.setProgressBarValue(i++);

			}
		;

		// final double inc = 100 / (double) millis;
		// double j = inc;
		// Updates progress bar
		// for (int i = 0; i < millis; i++, j += inc) {
		// try {
		// Thread.sleep(1);
		// SPLASH_SCREEN.setProgressBarValue((int) j);
		// } catch (InterruptedException e) {
		// e.printStackTrace();
		// }
		// }
		SPLASH_SCREEN.setVisible(false);
	}

	private Zephyr() {
	}
}
