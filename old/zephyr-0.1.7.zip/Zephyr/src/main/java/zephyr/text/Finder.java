package zephyr.text;

import java.util.ArrayList;

import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import zephyr.text.exceptions.StringNotFoundException;
import zephyr.ui.components.TextArea;

/**
 * @author Fuad Saud
 * 
 */
public class Finder {

	public static final byte FIND_NEXT = 1;

	public static final byte FIND_PREVIOUS = 2;

	private final TextArea textArea;

	private String search;

	private ArrayList<Integer> results;

	private int currentIndex = 0;

	private boolean wrapEnd = false;

	private boolean wrapBegin = false;

	private boolean updated;

	private StringNotFoundException lastException;

	public Finder(TextArea textArea) {
		this.textArea = textArea;
		if (textArea == null) {
			throw new IllegalArgumentException("Parameter cannot be null");
		}

		this.updated = false;

		textArea.getDocument().addDocumentListener(new DocumentListener() {

			@Override
			public void changedUpdate(DocumentEvent e) {
				updated = false;
			}

			@Override
			public void insertUpdate(DocumentEvent e) {
				updated = false;
			}

			@Override
			public void removeUpdate(DocumentEvent e) {
				updated = false;

			}
		});
	}

	public void find(String search, byte direction)
			throws StringNotFoundException {
		textArea.requestFocus();
		if (this.search == null || !this.search.equals(search) || !updated
				|| lastException != null) {
			this.search = search;
			TextDocument doc = textArea.getTextDocument();
			results = doc.find(search);
			this.updated = true;
			this.currentIndex = 0;
			if (results.size() == 0) {

				throw lastException = new StringNotFoundException();
			}

			lastException = null;
		}

		if (direction == FIND_PREVIOUS) {
			findPrevious();
		} else {
			findNext();
		}

	}

	private void findNext() {
		int caretPos = textArea.getCaretPosition();
		if (wrapEnd) {
			caretPos = 0;
			wrapEnd = false;
			wrapBegin = true;
		}
		// Finds the next result to be selected
		for (int i = 0; i < results.size(); i++) {
			if (currentIndex == results.size() - 1) {
				currentIndex = 0;
			}

			if (results.get(i) >= caretPos) {
				currentIndex = i;
				textArea.setCaretPosition(results.get(currentIndex));
				if (i != 0) {
					wrapBegin = false;
				}
				break;
			} else if (i == results.size() - 1) {
				// If there's no more matches ahead, return to begin.
				wrapEnd = true;
				wrapBegin = false;
				findNext();
				return;
			}
		}
		caretPos = textArea.getCaretPosition();
		textArea.setSelectionStart(caretPos);
		textArea.setSelectionEnd(caretPos + search.length());
	}

	private void findPrevious() {
		int caretPos = textArea.getCaretPosition();
		if (wrapBegin) {
			caretPos = textArea.getText().length();
			wrapBegin = false;
			wrapEnd = true;
		}

		boolean invertSelectionCaretPos = false;
		for (int i = results.size() - 1; i >= 0; i--) {
			if (currentIndex == 0) {
				currentIndex = results.size() - 1;
			}

			System.out.println("caretPos: " + caretPos);
			String selectedText = textArea.getSelectedText();
			if (!invertSelectionCaretPos && selectedText != null
					&& selectedText.equals(search)) {
				caretPos = caretPos - search.length();
				System.out.println("caret pos: " + caretPos);
				invertSelectionCaretPos = true;
			}

			System.out.println("Caretpos: " + caretPos + "Result: "
					+ results.get(i));
			if (results.get(i) < caretPos /*- (search.length() + 1)*/) {
				currentIndex = i;
				textArea.setCaretPosition(results.get(currentIndex));
				if (i != results.size() - 1) {
					wrapEnd = false;
				}
				break;
			} else if (i == 0) {
				// If there's no more matches back, return to end.
				wrapBegin = true;
				wrapEnd = false;
				findPrevious();
				return;
			}
		}
		caretPos = textArea.getCaretPosition();
		textArea.setSelectionStart(caretPos);
		textArea.setSelectionEnd(caretPos + search.length());
	}
}
