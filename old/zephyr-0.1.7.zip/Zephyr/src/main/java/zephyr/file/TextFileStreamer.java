package zephyr.file;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import zephyr.Zephyr;
import zephyr.text.TextDocument;

/**
 * This class is used to read and write text files. It is responsible to manage
 * streams
 * 
 * @author Fuad Saud
 * 
 */
public class TextFileStreamer {

	/**
	 * Open a file and returns it's contents (using a {@link BufferedReader}).
	 * 
	 * @param file
	 *            the {@link File} to be read.
	 * @return A {@link TextDocument} with the content and metadata retrieved
	 *         from the file.
	 * @throws FileNotFoundException
	 *             if the file does not exist, is a directory rather than a
	 *             regular file, or for some other reason cannot be open for
	 *             reading.
	 * @throws IOException
	 *             if an I/O error occurs
	 */
	public TextDocument open(File file) throws FileNotFoundException, IOException {
		FileReader fr = new FileReader(file);
		BufferedReader br = new BufferedReader(fr);
		StringBuilder builder = new StringBuilder();
		String line = null;

		while ((line = br.readLine()) != null) {
			builder.append(line + "\n");
		}

		builder.deleteCharAt(builder.length() - 1);

		br.close();

		String name = file.getName();
		String path = file.getPath();
		String content = builder.toString();

		return new TextDocument(name, path, content);
	}

	/**
	 * Open a file and returns it's contents (using a {@link BufferedReader}).
	 * The {@link File} is referenced by the path.
	 * 
	 * @param path
	 *            the path of the {@link File} to be read.
	 * @return A {@link TextDocument} with the content and metadata retrieved
	 *         from the file.
	 * @throws FileNotFoundException
	 *             if the file does not exist, is a directory rather than a
	 *             regular file, or for some other reason cannot be open for
	 *             reading.
	 * @throws IOException
	 *             if an I/O error occurs
	 */
	public TextDocument open(String path) throws FileNotFoundException, IOException {
		return open(new File(path));
	}

	/**
	 * Writes a text file (using a {@link PrintWriter}).
	 * 
	 * @param content
	 *            the string to be written.
	 * @param file
	 *            the destination {@link File}.
	 * @throws FileNotFoundException
	 *             if the given file object does not denote an existing,
	 *             writable regular file and a new regular file of that name
	 *             cannot be created, or if some other error occurs while
	 *             opening or creating the file
	 * @throws IOException
	 *             if an I/O error occurs.
	 */
	public void save(String content, File file) throws FileNotFoundException, IOException {
		// Defines which line separator should use
		String lineSeparator = Zephyr.lineSeparator();
		if (!lineSeparator.equals("\n")) {
			content = content.replace("\n", lineSeparator);
		}

		BufferedWriter bw = new BufferedWriter(new FileWriter(file));
		bw.write(content);
		bw.flush();
		bw.close();

	}

	/**
	 * Writes a text file (using a {@link PrintWriter}).
	 * 
	 * @param content
	 *            the string to be written.
	 * @param path
	 *            the path of the {@link File} to be written.
	 * @throws FileNotFoundException
	 *             if the given file object does not denote an existing,
	 *             writable regular file and a new regular file of that name
	 *             cannot be created, or if some other error occurs while
	 *             opening or creating the file
	 */
	public void save(String content, String path) throws FileNotFoundException, IOException {
		save(content, new File(path));
	}
}
