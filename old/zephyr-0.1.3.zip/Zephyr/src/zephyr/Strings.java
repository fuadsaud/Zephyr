package zephyr;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Strings {

	public static final String NAME = "Zephyr";

	public static final String FULL_NAME = "Zephyr Text Editor";

	public static final String VERSION = "0.1.3 Alpha";

	public static final String COPYLEFT = "Copyleft " + (char) 169
			+ " 2011 - Fuad Saud - Couple of rights reserveds :)";

	public static final String HOME_PAGE = "http://twitter.com/fuadsaud";

	public static final String JAVA = "Java" + (char) 153;

	public static final String MIGLAYOUT_LICENSE = "";

	public static final String IMAGES = "/zephyr/resources/";

	public static final String DESCRIPTION;

	static {

		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader("./res/License.txt"));
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
		StringBuilder builder = new StringBuilder();
		builder.append(COPYLEFT + "\n");
		String line = null;
		try {
			while ((line = br.readLine()) != null) {
				builder.append("\n" + line);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		DESCRIPTION = builder.toString();
	}

	private Strings() {
	}

}
