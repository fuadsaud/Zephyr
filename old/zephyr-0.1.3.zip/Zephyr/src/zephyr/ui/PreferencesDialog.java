package zephyr.ui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.UIManager;

import net.miginfocom.swing.MigLayout;
import zephyr.Strings;
import zephyr.Zephyr;

/**
 * A dialog to set simple preferences.
 * 
 * @author Fuad Saud
 * 
 */

public class PreferencesDialog extends JDialog {

	/**
	 * Serial version ID
	 */
	private static final long serialVersionUID = 3252739958878696995L;

	/**
	 * A map containing LaF's classes names, based on the short name.
	 */
	private static final Map<String, String> laf = new HashMap<String, String>();

	/**
	 * A combo box with the LaF options.
	 */
	private JComboBox<String> lafCombo;

	static {
		laf.put("Liquid", "com.birosoft.liquid.LiquidLookAndFeel");
		laf.put("Metal", "javax.swing.plaf.metal.MetalLookAndFeel");
		laf.put("Motif", "com.sun.java.swing.plaf.motif.MotifLookAndFeel");
		laf.put("Nimbus", "javax.swing.plaf.nimbus.NimbusLookAndFeel");
		laf.put("System", UIManager.getSystemLookAndFeelClassName());
	}

	/**
	 * Initializes the dialog.
	 * 
	 * @param owner
	 *            the Frame from which the dialog is displayed
	 */
	public PreferencesDialog(JFrame owner) {
		super(owner, Strings.NAME + " Settings", true);

		setLayout(new MigLayout());

		initLookAndFeel();
		initButtons();

		setSize(600, 300);
		setResizable(false);
		setLocationRelativeTo(owner);
	}

	/**
	 * Initializes dialog's buttons.
	 */
	private void initButtons() {
		JButton ok = new JButton("OK");
		ok.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				updateProperties();
				dispose();
			}
		});

		add(ok);

		JButton cancel = new JButton("Cancel");
		cancel.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});

		add(cancel, "span");
	}

	/**
	 * Initializes look and feel's options.
	 */
	private void initLookAndFeel() {
		JLabel lafLabel = new JLabel("Choose the \"look and feel\"");
		lafCombo = new JComboBox<String>(new String[] { "Liquid", "Metal",
				"Motif", "Nimbus", "System" });

		lafCombo.setSelectedItem(UIManager.getLookAndFeel().getClass()
				.getSimpleName().replace("LookAndFeel", ""));
		JLabel lafWarning = new JLabel(
				"The \"look and feel\" will change after restarting");
		add(lafLabel);
		add(lafCombo);
		add(lafWarning, "wrap");
	}

	/**
	 * Updates the {@linkplain Zephyr#PREFERENCES}, based on the changes made.
	 */
	private void updateProperties() {
		Zephyr.PREFERENCES.setProperty("laf",
				laf.get(lafCombo.getSelectedItem()));
	}
}
