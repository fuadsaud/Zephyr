package zephyr;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;

import javax.swing.UIManager;

import zephyr.ui.ZephyrUI;

/**
 * Bootstraps the application.
 * 
 * @author Fuad Saud
 * 
 */
public class Zephyr {

	public static final Properties PREFERENCES;

	static {
		PREFERENCES = new Properties();

		initialize();
	}

	/**
	 * Loads properties files.
	 */
	public static void initialize() {
		// Initialize PREFERENCES
		try {
			File file = new File("settings.properties");
			if (file.exists()) {
				FileReader fr = new FileReader(file);
				PREFERENCES.load(fr);
				fr.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @param args
	 *            Command line arguments.
	 */
	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel(PREFERENCES.getProperty("laf"));
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		ZephyrUI ui = new ZephyrUI(args);

		ui.setVisible(true);
	}

	/**
	 * Stores properties files and exits.
	 */
	public static void shutdown() {
		try {
			FileWriter fw = new FileWriter("settings.properties");
			PREFERENCES.store(fw, "Zephyr general settings");
			fw.close();
			System.exit(0);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
