package zephyr.file;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * This class is used to read and write text files. It is responsible to manage
 * streams
 * 
 * @author Fuad Saud
 * 
 */
public class TextFileStreamer {

	/**
	 * Open a file and returns it's contents (using a {@link BufferedReader}.
	 * 
	 * @param file
	 *            the {@link File} to be read.
	 * @return An array containing, in the index 0 the name of the file opened ,
	 *         in the index 1 the path of the file and in the index 1, the
	 *         content the content of {@code file}.
	 * @throws FileNotFoundException
	 *             if the file does not exist, is a directory rather than a
	 *             regular file, or for some other reason cannot be opened for
	 *             reading.
	 * @throws IOException
	 *             if an I/O error occurs
	 */
	public String[] open(File file) throws FileNotFoundException, IOException {
		FileReader fr = new FileReader(file);
		BufferedReader br = new BufferedReader(fr);
		StringBuilder builder = new StringBuilder();
		for (long i = 0; i < file.length(); i++) {
			builder.append((char) br.read());
		}

		br.close();

		String name = file.getName();
		String path = file.getPath();
		String content = builder.toString();

		return new String[] { name, path, content };
	}

	/**
	 * Open a file and returns it's contents (using a {@link BufferedReader}.
	 * The {@link File} is referenced by the path.
	 * 
	 * @param path
	 *            the path of the {@link File} to be read.
	 * @return An array containing, in the index 0 the name of the file opened ,
	 *         in the index 1 the path of the file and in the index 2, the
	 *         content the content of {@code file}.
	 * @throws FileNotFoundException
	 *             if the file does not exist, is a directory rather than a
	 *             regular file, or for some other reason cannot be opened for
	 *             reading.
	 * @throws IOException
	 *             if an I/O error occurs
	 */
	public String[] open(String path) throws FileNotFoundException, IOException {
		return open(new File(path));
	}

	/**
	 * Writes a text file (using a {@link PrintWriter}.
	 * 
	 * @param content
	 *            the string to be written.
	 * @param file
	 *            the destination {@link File}.
	 * @throws FileNotFoundException
	 *             if the given file object does not denote an existing,
	 *             writable regular file and a new regular file of that name
	 *             cannot be created, or if some other error occurs while
	 *             opening or creating the file
	 * @throws IOException
	 *             if an I/O error occurs.
	 */
	public void save(String content, File file) throws FileNotFoundException,
			IOException {
		BufferedWriter bw = new BufferedWriter(new FileWriter(file));
		bw.write(content);
		bw.flush();
		bw.close();

	}

	/**
	 * Writes a text file (using a {@link PrintWriter}.
	 * 
	 * @param content
	 *            the string to be written.
	 * @param path
	 *            the path of the {@link File} to be written.
	 * @throws FileNotFoundException
	 *             if the given file object does not denote an existing,
	 *             writable regular file and a new regular file of that name
	 *             cannot be created, or if some other error occurs while
	 *             opening or creating the file
	 */
	public void save(String content, String path) throws FileNotFoundException,
			IOException {
		save(content, new File(path));
	}
}
