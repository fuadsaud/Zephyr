package zephyr;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;
import java.util.Scanner;

import javax.swing.UIManager;

import zephyr.ui.SplashScreen;
import zephyr.ui.ZephyrUI;

/**
 * Bootstraps the application.
 * 
 * @author Fuad Saud
 * 
 */
public class Zephyr {

	public static final String VERSION = "0.1.4 Alpha";

	public static final String HOME_PAGE = "http://twitter.com/fuadsaud";

	public static final String JAVA = "Java" + (char) 153;

	public static final String LICENSE;

	// Properties
	public static final Properties DEFAULT_PROPERTIES;

	public static final Properties PREFERENCES;

	public static final Properties STRINGS;

	// Paths
	public static final String RESOURCES = "/zephyr/resources/";

	public static final String IMAGES = RESOURCES + "images/";

	public static final String LANGUAGES = RESOURCES + "languages/";

	public static final String SETTINGS = "settings.properties";

	private static final SplashScreen SPLASH_SCREEN;

	private static ZephyrUI ui;

	private static boolean endLoading = false;

	static {
		// Initializes Properties
		DEFAULT_PROPERTIES = new Properties();
		// Appearance properties
		DEFAULT_PROPERTIES.setProperty("laf",
				"javax.swing.plaf.metal.MetalLookAndFeel");
		DEFAULT_PROPERTIES.setProperty("language", "en-US");
		// Fonts
		DEFAULT_PROPERTIES.setProperty("font-size", "15");
		// Misc
		DEFAULT_PROPERTIES.setProperty("remember-current-session", "true");

		PREFERENCES = new Properties(DEFAULT_PROPERTIES);
		STRINGS = new Properties();

		initializeProperties();

		// Reads up the license
		BufferedInputStream bis = new BufferedInputStream(
				Zephyr.class.getResourceAsStream(RESOURCES + "License.txt"));
		Scanner scanner = new Scanner(bis);
		StringBuilder builder = new StringBuilder();
		builder.append(STRINGS.getProperty("copyleft") + "\n");

		while (scanner.hasNextLine()) {
			builder.append(scanner.nextLine() + "\n");
		}

		LICENSE = builder.toString();

		SPLASH_SCREEN = new SplashScreen();
	}

	/**
	 * Loads properties files.
	 */
	public static void initializeProperties() {
		try {
			// Initializes PREFERENCES
			File file = new File(SETTINGS);
			if (file.exists()) {
				FileReader fr = new FileReader(file);
				PREFERENCES.load(fr);
				fr.close();
			}

			// Initializes STRINGS
			STRINGS.load(Zephyr.class.getResourceAsStream(LANGUAGES
					+ PREFERENCES.getProperty("language")));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @param args
	 *            Command line arguments.
	 */
	public static void main(final String[] args) {
		try {
			UIManager.setLookAndFeel(PREFERENCES.getProperty("laf"));
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		// Showing the splash screen
		Thread splashScreenThread = new Thread(new Runnable() {

			@Override
			public void run() {
				showSplashScreen();
			}
		});
		splashScreenThread.start();

		ui = new ZephyrUI(args);

		// Holds the splash screen visible for a few seconds after the load
		try {
			Thread.sleep(750);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		endLoading = true;

		ui.setVisible(true);
	}

	/**
	 * Shows the splash screen until the loading is finished.
	 * 
	 */
	private static void showSplashScreen() {

		SPLASH_SCREEN.setVisible(true);
		while (!endLoading)
			;

		// final double inc = 100 / (double) millis;
		// double j = inc;
		// Updates progress bar
		// for (int i = 0; i < millis; i++, j += inc) {
		// try {
		// Thread.sleep(1);
		// SPLASH_SCREEN.setProgressBarValue((int) j);
		// } catch (InterruptedException e) {
		// e.printStackTrace();
		// }
		// }
		SPLASH_SCREEN.setVisible(false);
	}

	/**
	 * Stores properties files and exits.
	 */
	public static void shutdown() {
		try {
			FileWriter fw = new FileWriter("settings.properties");
			PREFERENCES.store(fw, "Zephyr general settings");
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.exit(0);
	}

	private Zephyr() {
	}
}
