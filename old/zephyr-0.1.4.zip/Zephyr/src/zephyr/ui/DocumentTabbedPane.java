package zephyr.ui;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;

/**
 * This class adds {@link JTabbedPane} some functions that automates actions
 * with Documents.
 * 
 * @author Fuad Saud
 * 
 */
public class DocumentTabbedPane extends JTabbedPane {

	/**
	 * Serial version ID.
	 */
	private static final long serialVersionUID = 4017762335863872321L;

	/**
	 * Creates an empty TabbedPane with a default tab placement of
	 * JTabbedPane.TOP.
	 */
	public DocumentTabbedPane() {
		super();
	}

	/**
	 * Adds a tab with a blank {@link Document} at the end of the components
	 * array;
	 * 
	 * @return the {@link Document} added.
	 */
	public Document addTab() {
		Document doc = new Document();
		super.addTab("Untitled", prepareDocument(doc));
		return doc;
	}

	/**
	 * Adds a tab with a {@link Document} created with the passed arguments.
	 * 
	 * @param name
	 *            the name of the new {@link Document}.
	 * @param path
	 *            the path of the new {@link Document}
	 * @param text
	 *            the content of the new {@link Document}
	 * @return the {@link Document} added.
	 */
	public Document addTab(String name, String path, String text) {
		Document doc = new Document(name, path, text);
		super.addTab(name, prepareDocument(doc));
		return doc;
	}

	/**
	 * Works like {@link JTabbedPane#getSelectedComponent()} but casts the
	 * component to {@link Document} before returning.
	 * 
	 * @return the {@link Document} inside the {@link GenericScrollPane} on the
	 *         <code>index</code>.
	 */
	@SuppressWarnings("unchecked")
	public Document getDocumentAt(int index) {
		return ((GenericScrollPane<Document>) super.getComponentAt(index))
				.getComponent();
	}

	/**
	 * Works like {@link JTabbedPane#getSelectedComponent()} but casts the
	 * component to {@link Document} before returning.
	 * 
	 * @return the {@link Document} inside the selected tab's
	 *         {@link GenericScrollPane}.
	 */
	@Override
	@SuppressWarnings("unchecked")
	public Document getSelectedComponent() {
		return ((GenericScrollPane<Document>) super.getSelectedComponent())
				.getComponent();
	}

	/**
	 * Adds a {@link KeyListener} to the passed document and adds it to a
	 * {@link GenericScrollPane}. The {@link KeyListener} puts a '*' at the
	 * begin of the tab name when the document content is changed.
	 * 
	 * @param doc
	 *            The doc to be prepared.
	 * @return The {@link GenericScrollPane} with the <code>doc</code> already
	 *         added.
	 */
	private GenericScrollPane<Document> prepareDocument(Document doc) {
		GenericScrollPane<Document> scroll = new GenericScrollPane<Document>();
		scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroll.getViewport().setBorder(null);
		doc.addKeyListener(new KeyListener() {

			@Override
			public void keyPressed(KeyEvent e) {

			}

			@Override
			public void keyReleased(KeyEvent e) {

			}

			@Override
			public void keyTyped(KeyEvent e) {
				setTitleStarAt(getSelectedIndex(), true);
			}
		});
		scroll.addOnViewPort(doc);
		return scroll;
	}

	/**
	 * Adds or removes the tab's title (referenced by <code>index</code> a '*'
	 * as the first character.
	 * 
	 * @param b
	 *            if <code>true</code> adds a '*' (if the string don't already
	 *            starts with one). Removes, case <code>false</code>.
	 * 
	 */
	public void setTitleStarAt(int index, boolean b) {
		if (b) {
			if (!getTitleAt(getSelectedIndex()).startsWith("*")) {
				setTitleAt(getSelectedIndex(), "*"
						+ getTitleAt(getSelectedIndex()));
			}
		} else if (getTitleAt(getSelectedIndex()).charAt(0) == '*') {
			setTitleAt(getSelectedIndex(), getTitleAt(getSelectedIndex())
					.substring(1));
		}
	}
}
