package zephyr.ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JTextArea;

import zephyr.Zephyr;

/**
 * This class is a swing component, adding some fields an ,methods to the
 * original {@link JTextArea} to document treatment (some flags to indicate
 * whether the text is modified since last save action, name, path, etc).
 * 
 * @author Fuad Saud
 * 
 */
public class Document extends JTextArea {

	/**
	 * Serial version ID.
	 */
	private static final long serialVersionUID = -7705771205773208800L;

	/**
	 * The name of the document.
	 */
	private String name;

	/**
	 * The path of the document on the disk.
	 */
	private String path;

	/**
	 * Indicates whether document is saved.
	 */
	private boolean saved;

	/**
	 * Indicates if the document was already flushed to the disc, independent of
	 * the {@code saved} flag.
	 */
	private boolean savedOnDisk;

	/**
	 * Indicates <code>true</code> when this is a just created blank document.
	 */
	private boolean newDocument;

	/**
	 * Creates a blank document with {@code name} "Untitled" and a null
	 * {@code path}.
	 */
	public Document() {
		this("Untitled", null, null);
		setSavedOnDisk(false);
		this.newDocument = true;
	}

	/**
	 * Creates a document with the specified name, path and content
	 * 
	 * @param name
	 *            the document name.
	 * @param path
	 *            the document path.
	 * @param content
	 *            the content to be set on text area.
	 */
	public Document(String name, String path, String content) {
		super(content);
		setDocName(name);
		setPath(path);

		setSaved(true);
		setSavedOnDisk(true);

		setTabSize(4);
		setLineWrap(true);
		int fontSize;
		try {
			fontSize = Integer.parseInt(Zephyr.PREFERENCES
					.getProperty("font-size"));
		} catch (NumberFormatException e) {
			fontSize = Integer.parseInt(Zephyr.DEFAULT_PROPERTIES
					.getProperty("font-size"));
			e.printStackTrace();
		}
		setFont(new Font("Courier New", Font.PLAIN, fontSize));
		setForeground(Color.BLACK);
		addKeyListener(new KeyListener() {

			@Override
			public void keyPressed(KeyEvent e) {

			}

			@Override
			public void keyReleased(KeyEvent e) {

			}

			@Override
			public void keyTyped(KeyEvent e) {
				setSaved(false);
			}
		});
	}

	/**
	 * Returns the name of the document.
	 * 
	 * @return the name of the document.
	 */
	public String getDocName() {
		return this.name;
	}

	/**
	 * Returns the path of the document.
	 * 
	 * @return the path of the document.
	 */
	public String getPath() {
		return path;
	}

	/**
	 * Returns <code>true</code> when this is a just created blank document.
	 * 
	 * @return the <code>newDocument</code> attribute.
	 */
	public boolean isNewDocument() {
		return newDocument;
	}

	/**
	 * Returns <code>true</code> if the document is saved; <code>false</code> if
	 * not.
	 * 
	 * @return the saved flag.
	 */
	public boolean isSaved() {
		return saved;
	}

	/**
	 * Returns <code>true</code> if the document is saved on the disk;
	 * <code>false</code> if not.
	 * 
	 * @return the savedOnDisk flag.
	 */
	public boolean isSavedOnDisk() {
		return savedOnDisk;
	}

	/**
	 * @param newDocument
	 *            the newDocument to set
	 */

	/**
	 * Sets the document name.
	 * 
	 * @param name
	 *            the new name.
	 */
	public void setDocName(String name) {
		this.name = name;
	}

	/**
	 * Sets the document path.
	 * 
	 * @param path
	 *            the path to set
	 */
	public void setPath(String path) {
		this.path = path;
	}

	/**
	 * Sets the {@code saved} attribute.
	 * 
	 * @param saved
	 *            the flag to set.
	 */
	public void setSaved(boolean saved) {
		this.newDocument = false;
		this.saved = saved;
	}

	/**
	 * Sets the {@code savedOnDisk} attribute.
	 * 
	 * @param savedOnDisk
	 *            the flag to set.
	 */
	public void setSavedOnDisk(boolean savedOnDisk) {
		this.savedOnDisk = savedOnDisk;
	}

}
